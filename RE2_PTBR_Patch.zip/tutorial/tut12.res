[MESSAGE]Bem, veja o que voc� tem a�; voc� acabou de receber um item misterioso! Itens misteriosos s�o objetos no jogo que podem fornecer uma infinidade de b�nus especiais, como um aumento saud�vel nas habilidades culin�rias do seu chef ou na moral da equipe.

Vamos dar uma olhada melhor nesses chamados itens misteriosos abrindo o _Painel de Equipe_ e _clicando com o bot�o esquerdo_ no �cone _Item Misterioso_ e ver do que se trata.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]A janela Mysterious Item � onde voc� pode encontrar todos os itens misteriosos que voc� coletou at� agora e ver os b�nus espec�ficos de cada item. Observe que alguns itens s� podem ser aplicados a determinados alvos, como chefs. Existem at� itens, raros e poderosos, que podem ser lan�ados em um restaurante inteiro. Como o nome sugere, os itens s�o misteriosos e t�m efeitos variados � � melhor serem encontrados do que falados.

Boa sorte em encontr�-los!
[POSITION]475,32
[DIMENSION]310,250
[HINT]
