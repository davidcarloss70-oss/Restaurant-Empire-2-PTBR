[MESSAGE]Parab�ns pelo seu novo restaurante!

Parece bom e espa�oso. No entanto, tamb�m parece que quem construiu este pitoresco "ristorante" se esqueceu de acrescentar algo - os banheiros! Isso � algo que temos que remediar. Primeiro, vamos abrir o _painel interior_ e ent�o _clicar com o bot�o esquerdo_ no bot�o _Salas e Texturas_.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]Agora, _clique com o bot�o esquerdo_ no bot�o _Adicionar salas_. Voc� notar� que existem tr�s op��es dispon�veis: _Banheiro Feminino_, _Banheiro Masculino_ e _Cozinha_. Como este restaurante j� tem cozinha, n�o iremos montar aqui. Basta dizer que quase tudo que voc� aprende aqui se aplica tanto a banheiros quanto a cozinhas.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]Antes de continuarmos, quero lembr�-lo de que a ajuda contextual est� dispon�vel para todas as a��es de coloca��o de itens. Basta olhar para a barra de mensagens na parte superior da tela para ver mensagens espec�ficas sobre o posicionamento do seu item, caso voc� n�o consiga colocar um item. Provavelmente voc� encontrar� a resposta l�.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]Pense em onde voc� est� adicionando um banheiro ou uma cozinha. Voc� pode, e deve, adicionar banheiros masculinos e femininos em todos os restaurantes, a menos que queira gerar reclama��es de clientes por n�o poder usar banheiros em seu estabelecimento!

Vamos adicionar um banheiro. Senhoras primeiro! _Clique com o bot�o esquerdo_ no bot�o _Banheiro Feminino_.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]Voc� notar� que o cursor mudou. Agora, para desenhar o primeiro canto da sala, _clique com o bot�o esquerdo_ no ch�o do restaurante, mas _mantenha o bot�o do mouse pressionado_!

Veja o pequeno quadrado vermelho? Esse � o canto inicial do seu banheiro. Agora, _arraste o mouse_ em qualquer dire��o no ch�o do restaurante. Voc� notar� que o quadrado aumenta de tamanho. Se o quadrado for grande o suficiente e n�o estiver obstru�do por objetos ou salas, o quadrado acabar� ficando verde.

Experimente agora. _Solte_ o _bot�o esquerdo do mouse_ quando o quadrado ficar verde. Se tiver algum problema, voc� pode sempre consultar a ajuda contextual localizada na parte superior da tela.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]E a� est�! Seu primeiro banheiro! Agora, para tornar o banheiro totalmente funcional, voc� precisa adicionar alguns itens, como uma _porta_, alguns _conjuntos de pia_ e a sempre popular _box_. Mas antes de colocar todos esses itens em seu banheiro novinho em folha, veremos como redimensionar e mover um banheiro ou qualquer outro c�modo.  _Clique com o bot�o esquerdo_ no bot�o _Ajustar salas_. Voc� notar� a mudan�a do cursor.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]Agora _clique com o bot�o esquerdo_ no ch�o do banheiro. Voc� ver� o ch�o come�ar a piscar em branco. Voc� tamb�m ver� quatro quadrados verdes, um em cada canto. Voc� pode _redimensionar_ a sala ou _mov�-la_ para outro lugar.

Para _redimensionar_ uma sala, _clique com o bot�o esquerdo_ em um quadrado verde e _mantenha o bot�o pressionado_. Em seguida, _arraste_ o quadrado verde para outro local do seu restaurante. Quando voc� _soltar_ o bot�o, sua sala ser� redimensionada.

Experimente e _clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]Bom! Para _mover_ uma sala inteira, _clique com o bot�o esquerdo_ no ch�o do banheiro novamente e, a seguir, _clique com o bot�o esquerdo_ na �rea branca. Sua sala parecer� �flutuar� e a �rea branca ficar� verde ou vermelha, dependendo se voc� pode colocar a sala l� ou n�o.

Desde que a �rea permane�a verde, voc� pode mover a sala para outra �rea do seu restaurante. Para confirmar a mudan�a, _clique com o bot�o esquerdo_ na �rea verde.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]�timo! Para excluir uma sala, _clique com o bot�o esquerdo_ no bot�o _Excluir salas_. Voc� notar� a mudan�a do cursor. Em seguida, _clique duas vezes_ no ch�o do banheiro para exclu�-lo.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]Excelente! Voc� est� realmente pegando o jeito! Agora vamos fazer isso de verdade. Coloque dois banheiros - um masculino e outro feminino, completos com porta, dois conjuntos de pia e tr�s cub�culos cada.

Quando terminar, _clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]Fant�stico! Agora veremos a interface _Item Detail_. Primeiro, vamos adicionar uma mesa ao restaurante. Em segundo lugar, adicione uma lumin�ria de parede. Eles podem ser encontrados no bot�o _Ilumina��o e instala��es do restaurante_.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]Agora, _clique duas vezes_ na mesa.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]A interface _Item Detail_ aparecer�, exibindo o nome do conjunto de tabelas, bem como um modelo 3D. Tamb�m indicar� o custo mensal de manuten��o do item, bem como seus valores de conforto e decora��o, que contam para a avalia��o do seu restaurante.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]V� os bot�es de _seta_ e a _barra de exibi��o_ entre as setas? Voc� pode usar as setas para visualizar as diferentes op��es dispon�veis em _amenidades de mesa_, mas outra maneira mais f�cil de visualizar os itens � _clicar com o bot�o esquerdo_ na _barra de exibi��o_. Isso mostrar� uma lista suspensa de comodidades dispon�veis. Experimente agora e _role para baixo_ at� encontrar _Dining Table Light_ e _clique com o bot�o esquerdo_ nele.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]Voc� pode ver que a interface agora mostra uma pr�via do item pr�ximo ao bot�o _seta para a esquerda_. Isso significa que a l�mpada atual est� selecionada.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]Agora observe os outros dois bot�es de _seta_ e a _barra de exibi��o_. Aqui voc� pode escolher se deseja _Aplicar_ a _Luz da mesa de jantar_ _somente nesta mesa_, _Aplicar a mesas semelhantes_ ou _Aplicar a todas as mesas_. Coloque esta luz em todas as mesas para continuar.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]Bom trabalho! Agora todas as mesas do restaurante ter�o a mesma luz. Agora _clique duas vezes_ em qualquer lumin�ria de parede. A interface _Item Detail_ aparecer� novamente, desta vez indicando informa��es relevantes sobre a l�mpada. Se voc� deseja alterar o raio ou intensidade de ilumina��o da luz, _clique com o bot�o esquerdo e arraste o controle deslizante_ para ajustar as configura��es. Mais uma vez, voc� pode usar o menu suspenso ou as setas para escolher como deseja aplicar as configura��es.

Quando terminar as configura��es de luz, _clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]Agora vou explicar como designar chefs espec�ficos para preparar receitas espec�ficas. Primeiro, abra o _menu de receitas_ e adicione a receita de _Mussarela Marinada Picante com Or�gano e Alcaparras_ ao seu _menu de Comida_.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]Agora, abra seu _menu de comida_ e _destaque_ a receita de _Mussarela Picante Marinada com Or�gano e Alcaparras_. Observe o pequeno �cone do chef? Esse � o bot�o _Atribuir Chef_. _Clique com o bot�o esquerdo_ agora. Voc� ver� a interface _Atribui��es de Chef e Ingredientes_.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]Observe a _barra de exibi��o_? Esse � o chef atualmente em destaque. Neste momento, n�o pode designar mais ningu�m para preparar esta receita, porque s� tem um chef neste restaurante! Se voc� tivesse mais chefs, poderia usar os _bot�es de seta_ que normalmente aparecem nas laterais da _barra de exibi��o_. Por enquanto, vamos ficar com Mario.

Para designar o jovem Corleone para cozinhar esta receita, _clique com o bot�o esquerdo_ na caixa de sele��o _Atribuir Chef_ para continuar. Uma marca de sele��o aparecer� para confirmar, o que significa que sempre que um cliente solicitar esta receita, Mario Corleone ir� prepar�-la, mesmo que haja outros chefs por perto.
[POSITION]572,27
[DIMENSION]228,250

[MESSAGE]Agora d� uma olhada na coluna direita da interface. Esta � a coluna _Ingredientes Estocados_. Voc� notar� muitas barras vazias, exceto uma que diz �Caper�. Isso significa que Mario carrega um ingrediente necess�rio para a confec��o da receita. Se voc� quiser que o chef prepare a receita com o ingrediente armazenado, _clique com o bot�o esquerdo_ na _caixa de sele��o_ ao lado do nome do ingrediente. Experimente agora.
[POSITION]572,27
[DIMENSION]228,250

[MESSAGE]Por que designar chefs e ingredientes estocados, voc� pergunta? Simples! Quanto mais um chef dedica seu tempo e esfor�os a uma receita, mais experi�ncia ele ganha e, portanto, melhor ser� o sabor da receita! Os ingredientes estocados tamb�m tendem a ser de melhor qualidade, o que significa que sua receita s� pode melhorar com o tempo.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]572,27
[DIMENSION]228,250

[MESSAGE]Se voc� deseja redefinir as atribui��es do chef, _clique com o bot�o esquerdo_ na marca de sele��o novamente para desmarc�-la. Nenhum chef ser� designado para essa receita. Se voc� deseja redefinir as atribui��es de ingredientes, _clique com o bot�o esquerdo_ no bot�o _Desmarcar todos os ingredientes_.

_Clique com o bot�o esquerdo_ em _OK_ para continuar.
[POSITION]572,27
[DIMENSION]228,250

[MESSAGE]Agora vou apresentar um conceito essencial na ind�stria de alimentos e bebidas: o fornecimento de ingredientes selecionados. Todos sabemos que para preparar receitas de qualidade n�o s�o necess�rias apenas habilidades de chef de qualidade, mas tamb�m ingredientes de qualidade. Ao longo de sua carreira como dono de restaurante, voc� encontrar� clientes que poder�o lhe fornecer fornecedores de ingredientes. Esses fornecedores diferem dos fornecedores normais porque seus ingredientes s�o invariavelmente melhores. Ent�o voc� deve a si mesmo tentar obter esses contatos! Cada vez que voc� vir um cliente com uma grande seta verde acima de suas cabe�as, _clique com o bot�o esquerdo_ no cliente e ele lhe dir� n�o apenas locais de fornecedores de ingredientes especiais, mas tamb�m poder� lhe contar segredos culin�rios.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]Voc� pode comprar ingredientes de qualidade desses fornecedores simplesmente selecionando receitas no _Menu de Receitas_ que possuem o �cone _Fornecedor Especial_ na lista de ingredientes e _clicando com o bot�o esquerdo_ nesse bot�o. A interface _Fornecedor Especial_ aparecer� e voc� poder� fazer suas compras de ingredientes especiais l�.
[POSITION]374,318
[DIMENSION]320,250

[MESSAGE]Para as pr�ximas etapas, voc� ter� que abrir seu restaurante primeiro para permitir a entrada de clientes! Donn�o se preocupe se neste momento seu restaurante n�o estiver totalmente configurado. Apenas certifique-se de ter algumas receitas, alguns funcion�rios a bordo e algumas receitas para seus clientes escolherem.

Depois de configurar as necessidades b�sicas de um restaurante e alguns clientes se preparando para comer, _clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar, mas lembre-se de que voc� passar� para a pr�xima etapa somente se tiver terminado de configurar o restaurante, abri-lo para neg�cios e receber clientes. Voc� pode querer minimizar a janela do tutorial para esta etapa.
[POSITION]374,318
[DIMENSION]320,250

[MESSAGE]O �ltimo conceito que vou explicar � sobre a satisfa��o do cliente. Existem muitas maneiras de avaliar a satisfa��o do cliente. Primeiro, vamos dar uma olhada em seus �ndices de satisfa��o. Para fazer isso, _clique com o bot�o esquerdo_ no bot�o _Painel do Cliente_.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]Agora, _clique com o bot�o esquerdo_ em qualquer cliente da sua lista de clientes. Seu novo restaurante pode ainda n�o ter clientes neste momento. Se voc� ainda n�o tem clientes, minimize a janela do tutorial e se esforce para atrair alguns clientes para o seu restaurante. Quando os clientes come�arem a entrar, continue com este tutorial selecionando um cliente na sua lista de clientes.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]_Clique com o bot�o esquerdo_ no bot�o _Perfil do cliente_. Voc� ver� uma an�lise detalhada do cliente selecionado.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]Preste aten��o especial ao indicador de classifica��o de _Satisfa��o_. Quanto mais rostos felizes, mais satisfeito o cliente fica. Voc� tamb�m pode ver a _Expectativa de qualidade_ do cliente logo acima dos indicadores _Qualidade real dos alimentos_ e _Satisfa��o_. A satisfa��o do cliente � alta quando a qualidade da comida do cliente atende ou supera as expectativas do cliente. Esforce-se para que a classifica��o de _Qualidade Real dos Alimentos_ seja superior �s expectativas do cliente e voc� ficar� bem. Se voc� vir um cliente com cinco rostos felizes, poder� dizer com seguran�a que o cliente descobriu o nirvana culin�rio!

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]Existem outras maneiras de aumentar os n�veis de satisfa��o dos clientes em seus restaurantes. Uma delas � diminuir o pre�o do card�pio. Alguns clientes n�o se importam em pagar mais pela qualidade, mas tenho certeza de que ningu�m se importar� se a mesma qualidade puder ser obtida por um pre�o mais barato!

Agora _clique com o bot�o esquerdo_ no bot�o _Reclama��es do cliente_. Voc� ver� uma lista de reclama��es. Uma das maneiras mais eficazes de agradar os clientes � atender �s suas reclama��es individuais. Agora, embora seja verdade que voc� simplesmente n�o consegue agradar a todos, voc� ver� menos rostos azedos se realmente fizer algo a respeito das reclama��es deles!

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]Outra dica que posso oferecer � retirar do card�pio receitas que seus chefs n�o s�o bons em preparar. Isso ajudar� seu restaurante a manter uma qualidade consistentemente alta dos alimentos oferecidos. Voc� pode ver um resumo da qualidade dos alimentos vendidos no relat�rio Vendas no Centro de Informa��es.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]Antes de deixar voc� com isso, aqui vai um conselho: quanto maior o reconhecimento do cliente do restaurante, mais clientes vir�o ao restaurante. Voc� pode visualizar os n�veis de conhecimento do seu restaurante e os clientes di�rios esperados no _Painel de detalhes do restaurante_.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]Outros fatores que afetam seus clientes di�rios esperados incluem a localiza��o do restaurante e a _Classifica��o do restaurante_, que pode ser visualizada na interface do _Centro de Informa��es_, em _Relat�rios_.

Procure agradar seus clientes, e eles ir�o agrad�-lo com resultados que beneficiar�o seu restaurante e toda a sua opera��o como um todo!
[POSITION]535,15
[DIMENSION]320,250
