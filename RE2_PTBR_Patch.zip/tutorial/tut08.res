[MESSAGE]Parab�ns por possuir sua primeira cafeteria! Neste tutorial falaremos sobre como voc� pode montar o balc�o da sua cafeteria e preparar a sele��o do card�pio que oferecer� aos seus clientes.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Ao abrir o _Menu de Receitas_, voc� poder� perceber que as receitas dispon�veis s�o diferentes das dos restaurantes. Aqui, o card�pio � dividido em cinco categorias - _Caf� Quente_, _Caf� Gelado_, _Ch�_, _Outras Bebidas_ e _Comida_. Assim como as receitas de restaurantes, diferentes itens do menu de cafeterias podem ter diferentes requisitos de instala��es para prepar�-los.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Uma coisa que voc� deve sempre lembrar ao abrir uma cafeteria � que ela requer uma cozinha e um balc�o para funcionar corretamente. De referir ainda que uma s�rie de facilidades s� podem ser acrescentadas quando existe uma �rea de balc�o dispon�vel. Como voc� pode ver na loja, a cozinha j� foi constru�da para voc�.

Vamos agora construir uma nova �rea de balc�o para sua cafeteria. V� em frente e abra o _Painel Interior_ e escolha o �cone _Salas e Texturas_.  Agora selecione _�rea de Balc�o_ no painel _Adicionar Salas_ e arraste a �rea da nova sala no ch�o onde deseja coloc�-la.

Um conselho: � uma boa ideia colocar sempre a �rea do balc�o o mais pr�ximo poss�vel da cozinha, pois o seu chef ir� frequentemente alternar entre a cozinha e a �rea do balc�o para utilizar as respetivas instala��es.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Agora que a sala est� pronta, vamos come�ar a adicionar algumas facilidades a ela. Com a _�rea do Balc�o_ selecionada, v� para o Painel Interior e clique no bot�o _Aparelhos e Instala��es do Balc�o_ e adicione um _Balc�o Frontal_ � sua �rea de balc�o vazia. O _Balc�o_ pode ter duas fun��es: mesa de prepara��o para os chefs e tamb�m posto de espera para gar�ons buscarem comida para entrega.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]V�rios equipamentos de cozinha tamb�m podem ser colocados em cima de um _balc�o frontal_ semelhante � _mesa de cozinha_ nas cozinhas de seus restaurantes. E assim como o _Balc�o Frontal_, voc� tamb�m pode adicionar um _Balc�o Traseiro_ � sua cafeteria caso sinta que n�o tem espa�o suficiente para colocar todos os seus equipamentos. Agora v� em frente e tente colocar todos os utens�lios de cozinha que faltam mostrados no _Menu de Receitas_ em sua �rea de balc�o.

Quando terminar, basta pressionar o bot�o _Avan�ar_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Excelente! Sua cafeteria est� quase pronta. Lembre-se de arrumar todos os m�veis restantes, contratar pessoal adequado e preparar bem o card�pio de comida e voc� estar� a caminho da inaugura��o de sua primeira cafeteria. Boa sorte!
[POSITION]475,32
[DIMENSION]310,250
[HINT]
