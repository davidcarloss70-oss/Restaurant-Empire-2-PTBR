[MESSAGE]Excelente! Agora vamos falar sobre como voc� vai montar uma apresenta��o ao vivo para o seu restaurante. As apresenta��es ao vivo ajudam a melhorar a classifica��o do seu restaurante, o que, por sua vez, ajuda a atrair mais clientes. Para come�ar, vamos descobrir quais performances est�o dispon�veis para voc�.

Abra a _Lista de relat�rios_ no _Centro de informa��es_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Na _Report List_, voc� encontrar� a _Performance List_ exibindo todas as apresenta��es ao vivo atualmente dispon�veis. Como voc� pode ver, por enquanto voc� s� pode contratar "%s" para se apresentar em seu restaurante. � medida que voc� conhece e conversa com pessoas diferentes, sua sele��o de artistas dispon�veis para contrata��o aumentar�.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]A _Performance List_ oferece uma vis�o das estat�sticas e requisitos de cada artista ao vivo.

Diferentes artistas exigem diferentes palcos para apresentar seu show. Ao clicar no performer "%s", voc� poder� ver quais etapas de atua��o s�o adequadas para sua atua��o.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Conforme mencionado, os artistas s� poder�o realizar seus atos quando voc� lhes fornecer o palco de atua��o adequado. Vamos tentar ent�o.

Voc� pode encontrar o est�gio de desempenho de royalties na categoria _Acess�rio_ do _Painel Interior_. Agora libere algum espa�o e adicione o palco de apresenta��es ao seu refeit�rio.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Bom trabalho! Vamos agora atribuir o performer a esta fase.

_Llique duas vezes com o bot�o esquerdo_ no est�gio de desempenho para visualizar as propriedades do item.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Esta � a interface _Detalhes de desempenho_. Voc� notar� que atualmente n�o h� nenhuma apresenta��o ao vivo vinculada a este palco. Precisaremos adicionar um ent�o.

_Clique com o bot�o esquerdo_ no bot�o _Adicionar desempenho_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]A interface _Performance List_ mostra todas as performances dispon�veis para este palco espec�fico.  Para atribuir um ato ao seu palco, destaque o artista e clique com o bot�o esquerdo em OK para atribu�-lo ao palco. Quando voc� j� tem um artista atribu�do, mas n�o deseja mais usufruir de seus servi�os, voc� pode selecionar "Sem apresenta��o" para remov�-lo.

Destaque o artista "%s" e _clique com o bot�o esquerdo_ no bot�o _OK_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Bom trabalho! Voc� acabou de atribuir "%s" ao est�gio de desempenho.

_Lamba duas vezes com o bot�o esquerdo_ no palco da performance para revisar os detalhes desta performance.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]A performance ser� paga de acordo com o valor da hora e a dura��o do ato. Uma dura��o mais longa melhorar� melhor a classifica��o do seu restaurante, mas ser� naturalmente mais cara.

Vamos alterar o hor�rio de in�cio da performance para %02d:%02d e a dura��o para %d hora(s).

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]�timo! Voc� terminou de configurar a apresenta��o ao vivo. Mas antes de encerrarmos, h� uma �ltima coisa a ver.

Abra os _Relat�rios_ na interface do _Centro de Informa��es_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Em _Relat�rios_, encontre a categoria Classifica��o de restaurantes. O efeito da apresenta��o ao vivo no seu restaurante � mostrado na _Classifica��o Ambiental_. A classifica��o do seu restaurante � melhorada de acordo com a classifica��o e dura��o do desempenho. Lembre-se sempre de que a remo��o de uma apresenta��o redefinir� a classifica��o acumulada da apresenta��o ao vivo do restaurante. Observe tamb�m que ajustar a posi��o de um palco n�o afetar� a classifica��o de desempenho. E � isso para apresenta��es ao vivo. Seguindo estes passos simples e brincando um pouco mais, seu restaurante estar� repleto de entretenimento em pouco tempo.
[POSITION]475,32
[DIMENSION]310,250
[HINT]
