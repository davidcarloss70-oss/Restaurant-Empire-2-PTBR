[MESSAGE]Muito bem, Armand! Agora que voc� j� sabe como decorar seu restaurante, vamos ver o que voc� vai servir aos seus clientes - afinal, este � um estabelecimento de alimenta��o!

_Clique com o bot�o esquerdo_ no bot�o _Menu de comida_. Voc� ver� a capa do menu do seu restaurante. Voc� ainda n�o tem nenhum prato configurado no card�pio, ent�o essa � a primeira coisa que vamos remediar.
[POSITION]475,32 
[DIMENSION]310,250
[HINT]155,565,190,595

[MESSAGE]Abaixo do menu est� a _interface do menu de comida_. Existem v�rios bot�es, mas por enquanto vamos nos concentrar em adicionar receitas ao seu menu - explicarei os outros bot�es com mais detalhes posteriormente. Vamos adicionar uma receita ao seu card�pio agora. Para fazer isso, _clique com o bot�o esquerdo_ no bot�o _Adicionar receita_.
[POSITION]475,32 
[DIMENSION]310,250
[HINT]334,457,647,494

[MESSAGE]Voc� notar� que a interface do _menu de comida_ foi trocada pela _interface de receitas_, o reposit�rio de todas as suas receitas dispon�veis. Como voc� est� apenas come�ando, voc� s� tem algumas receitas dispon�veis. Os cinco bot�es quadrados na parte superior da _interface de receitas_ representam categorias de pratos de alimenta��o. _Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,32 
[DIMENSION]310,250
[HINT]193,106,356,134

[MESSAGE]Abaixo dos bot�es do curso de comida h� um painel de receitas visualizadas no momento, bem como seu nome. O painel de receitas tamb�m possui dois bot�es de seta redondos que podem ser usados ??para avan�ar e voltar na lista de receitas - neste caso, os _Pratos Principais_. V� em frente - experimente agora. _Clique com o bot�o esquerdo_ nos bot�es de seta para percorrer as receitas dispon�veis. Quando terminar, _clique com o bot�o esquerdo_ no bot�o _Avan�ar_.
[POSITION]475,32 
[DIMENSION]310,250
[HINT]116,137,331,183

[MESSAGE]Observe os �cones de bandeira no final de cada receita? Os �cones de bandeira indicam a adequa��o de uma receita para uma determinada cozinha - receitas francesas com cozinha francesa, receitas italianas com cozinha italiana, e assim por diante. �s vezes h� mais de um �cone de bandeira para uma determinada receita. Isso significa que a receita � adequada para mais de uma cozinha.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,32 
[DIMENSION]310,250
[HINT]116,137,331,183

[MESSAGE]Agora, em vez de percorrer a lista uma por uma usando os bot�es de seta, vamos abrir a lista suspensa. Simplesmente _clique com o bot�o esquerdo_ em qualquer lugar na _Exibi��o do nome da receita_. Experimente. Voc� poder� visualizar v�rias receitas ao mesmo tempo. Voc� tamb�m pode usar a barra de rolagem para subir e descer sua lista.

Por que voc� n�o escolhe uma receita agora? Simplesmente _clique com o bot�o esquerdo_ em uma receita.
[POSITION]475,32 
[DIMENSION]310,250
[HINT]

[MESSAGE]Voc� notar� na parte inferior da _Recipe Interface_ quatro bot�es grandes e redondos. Estes s�o, da esquerda para a direita, os bot�es _Receita Duplicada_, _Adicionar ao Menu de Comida_, _Exibir Menu de Comida_ e _Alternar Filtragem_. Para adicionar esta receita ao seu menu, _clique com o bot�o esquerdo_ no bot�o _Adicionar ao menu de comida_. Uma janela pop-up aparecer� confirmando a nova entrada de receita em seu menu.
[POSITION]475,32 
[DIMENSION]310,250
[HINT]206,458,350,494

[MESSAGE]Para ver sua nova receita no menu, _clique com o bot�o esquerdo_ no bot�o _Ver menu de comida_.
[POSITION]475,32 
[DIMENSION]310,250
[HINT]206,458,350,494

[MESSAGE]Agora voc� est� de volta � interface do _Food Menu_, com a diferen�a de que adicionamos uma receita. Agora pelo menos os clientes podem pedir alguma coisa!

Esta � uma sele��o bastante espartana que voc� oferece. Vamos tentar diversificar o card�pio repetindo o procedimento para adicionar mais receitas. Quando terminar de estabelecer seu menu, _clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,32 
[DIMENSION]310,250
[HINT]

[MESSAGE]Certifique-se de visualizar a interface do menu Comida para a pr�xima etapa. Observe no menu de comida como os bot�es de seta aparecem nos cantos inferiores das p�ginas do menu? Use estes bot�es para percorrer as p�ginas do seu menu. Por que voc� n�o v� o que decidiu oferecer � sua futura clientela _clicando com o bot�o esquerdo_ nos bot�es de seta da _p�gina anterior_ e da _pr�xima p�gina_?

Quando terminar de visualizar as receitas em seu menu, _clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,32 
[DIMENSION]310,250
[HINT]104,423,696,443

[MESSAGE]At� agora tudo bem! Agora que voc� entende os princ�pios b�sicos para adicionar receitas ao seu card�pio, vamos ver que outras coisas voc� pode fazer para tornar a estadia dos seus clientes ainda mais agrad�vel. Agora que os clientes podem saborear suas receitas, eles v�o querer algo para acompanhar suas refei��es.

Vamos adicionar servi�os de bebidas ao seu restaurante _clicando com o bot�o esquerdo_ no bot�o _Adicionar bebida_.
[POSITION]475,32 
[DIMENSION]310,250
[HINT]530,461,565,492

[MESSAGE]Um pop-up com uma lista de bebidas quentes e frias aparecer�. As bebidas geladas s�o ainda divididas em alco�licas e n�o alco�licas. Todas as bebidas v�m com um pre�o de compra fixo, ent�o tudo que voc� precisa fazer � _clicar com o bot�o esquerdo_ nas caixas de sele��o � esquerda de cada bebida para inclu�-la como parte do servi�o do seu restaurante. Quando terminar de escolher as bebidas, _clique com o bot�o esquerdo_ no bot�o _OK_ na parte inferior da lista de bebidas.
[POSITION]475,32 
[DIMENSION]310,250
[HINT]

[MESSAGE]Caso voc� n�o tenha notado, gostaria de lhe dar uma palavra sobre bebidas alco�licas: se voc� planeja servir bebidas alco�licas, precisar� pagar antecipadamente uma taxa de licen�a de bebidas alco�licas de US$ 20.000 antes de poder servir bebidas alco�licas. Apesar dos custos de licenciamento, isto � uma pechincha, uma vez que as bebidas alco�licas proporcionam as maiores margens de lucro.

_Clique com o bot�o esquerdo_ no _bot�o Avan�ar_ para continuar.
[POSITION]475,32 
[DIMENSION]310,250
[HINT]

[MESSAGE]Vamos preparar o design do menu. H� tr�s coisas que voc� pode fazer para alterar a apar�ncia do seu menu: voc� pode alterar a fonte do t�tulo, a fonte do texto e o design do plano de fundo do seu menu. Vamos come�ar alterando a fonte do t�tulo. _Clique com o bot�o esquerdo_ no bot�o _Title Font_. Dois bot�es de seta aparecer�o nas laterais. Use esses bot�es de seta para percorrer as fontes dispon�veis at� encontrar uma fonte de sua prefer�ncia. Em seguida, desative o bot�o _Title Font_ _clicando com o bot�o esquerdo_ nele novamente.
[POSITION]475,32 
[DIMENSION]310,250
[HINT]337,460,369,493

[MESSAGE]Voc� tamb�m pode _clicar com o bot�o esquerdo_ nos bot�es _Fonte do texto_ e _Fundo_ para alterar a apar�ncia do menu do seu restaurante. Projete seu menu at� personaliz�-lo de acordo com sua prefer�ncia - e de acordo com as prefer�ncias do seu restaurante.

Quando terminar, _clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,32 
[DIMENSION]310,250
[HINT]374,456,452,494

[MESSAGE]S� falta um pouco mais. Se voc� quiser ver detalhes sobre qualquer receita em seu menu, basta _clicar duas vezes_ no nome da receita e voc� ser� levado de volta � interface do _Menu de Receitas_, onde poder� ver informa��es detalhadas sobre aquela receita. V� em frente - experimente. Verifique os detalhes de qualquer receita _clicando duas vezes_ em uma entrada de receita em seu menu.
[POSITION]475,32 
[DIMENSION]310,250
[HINT]159,184,382,220

[MESSAGE]Observe o _Pre�o padr�o_ no _Menu de receitas_, que � o pre�o de venda dessa receita no seu restaurante.

Quando estiver pronto, _clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,32 
[DIMENSION]310,250
[HINT]85,448,202,494

[MESSAGE]A �ltima coisa que quero abordar com voc� � a interface do _Menu de Comida_, ent�o abra a interface do _Menu de Comida_ se ainda n�o tiver feito isso _clicando com o bot�o esquerdo_ no bot�o _Exibir Menu de Comida_.
[POSITION]475,32 
[DIMENSION]310,250
[HINT]279,460,312,494

[MESSAGE]Se voc� quiser se livrar de uma receita do menu, digamos, devido a vendas fracas, ent�o _destaque a receita_ em mente _clicando com o bot�o esquerdo_ no nome da receita e, em seguida, _clique com o bot�o esquerdo_ no bot�o _Excluir receita_ localizado na parte inferior da interface do _Menu de comida_. A receita destacada ser� removida do seu menu. Experimente agora - remova qualquer receita existente do seu menu. Uma janela pop-up solicitar� que voc� confirme a exclus�o. _Clique com o bot�o esquerdo_ no bot�o _OK_ para continuar.

Caso mude de ideia, voc� ainda pode voltar � interface da receita para adicion�-la novamente ao menu de comida.
[POSITION]402,33 
[DIMENSION]400,200
[HINT]611,462,645,492

[MESSAGE]Excelente! Voc� est� se tornando bastante habilidoso em fazer malabarismos com receitas e card�pios! Agora tudo o que voc� precisa fazer � configurar corretamente o card�pio de comida do seu novo restaurante, usando as habilidades que acabou de aprender neste tutorial.

Na hora de montar o seu card�pio, lembre-se que variedade � o tempero da vida! Tente adicionar o m�ximo poss�vel de receitas de caf� da manh�, aperitivos, sopas, pratos principais e sobremesas. Isso dar� a seus clientes uma ampla sele��o de ofertas para usar. E n�o se esque�a das bebidas!

Depois de configurar o card�pio do seu restaurante, h� uma �ltima coisa que quero mostrar antes de me sentir confiante para libert�-lo no mundo da alta culin�ria. _Encontre-me em minha casa para seu pr�ximo curso intensivo sobre como se tornar um dono de restaurante!_
[POSITION]475,32 
[DIMENSION]310,250
[HINT]
