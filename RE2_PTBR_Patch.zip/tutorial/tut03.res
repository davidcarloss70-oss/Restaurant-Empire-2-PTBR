[MESSAGE]Voc� adicionou decora��o e colocou receitas no card�pio, mas quem vai anotar os pedidos? Quem vai preparar as receitas? Quem garantir� que os clientes paguem?

Nenhum homem � uma ilha. Se voc� pensar em expandir e abrir mais restaurantes, precisar� de mais m�o de obra! Ent�o, vamos ver como podemos contratar pessoal para ajud�-lo em suas fa�anhas epicuristas. Vamos examinar isso agora. A primeira coisa � localizar o bot�o _Painel Staff_. _Clique com o bot�o esquerdo_ nele agora.
[POSITION]475,32
[DIMENSION]310,250
[HINT]250,560,287,596

[MESSAGE]Al�m do seu nome, a lista de funcion�rios est� quase completamente vazia. Isso � compreens�vel � voc� ainda n�o contratou ningu�m para trabalhar para voc�!

H� uma coluna de bot�es pr�ximo ao centro direito da interface da lista de funcion�rios. Eles s�o, de cima para baixo, os bot�es _Mudar para Modo Lista_, _Contratar Pessoal_, _Aumentar/Diminuir Sal�rio_, _Transferir Pessoal_ e _Demitir Pessoal_. Por enquanto, vamos nos concentrar no bot�o Contratar Pessoal. _Clique com o bot�o esquerdo_ nele agora.
[POSITION]180,340
[DIMENSION]600,400
[HINT]170,202,204,330

[MESSAGE]Observe como a interface agora exibe muitas informa��es! Vamos dividir essas informa��es em peda�os diger�veis, certo?

Vamos come�ar do topo da interface e descer. Observe os dois bot�es redondos na parte superior da interface? Um retrata um chef e outro um gar�om. Eles servem para alternar entre _Painel Chef_ e _Painel Waitstaff_.

Se voc� _clicar com o bot�o esquerdo_ no bot�o _Waitstaff Panel_ voc� ver� que as informa��es exibidas mudam para mostrar informa��es relevantes da equipe.
[POSITION]180,340
[DIMENSION]600,400
[HINT]130,49,190,78

[MESSAGE]Qualquer restaurante precisa de pelo menos um _Chef_ para preparar as receitas, um _Capit�o_ para receber os pedidos, um _Servidor_ para, bem, servir a comida e uma _Recepcionista_ para mostrar aos clientes seus lugares. Ah, e quase esqueci: voc� precisa contratar um _Kitchen Porter_ para lavar a lou�a!

V� em frente e contrate todos esses cargos. N�o h� necessidade de contratar um chef quando voc� tem confian�a para trabalhar na cozinha!

Quando terminar de contratar, _clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]180,340
[DIMENSION]600,400
[HINT]130,49,160,78

[MESSAGE]Uma palavra sobre os Recepcionistas: eles s� podem desempenhar as suas fun��es de forma eficaz se tiverem um _Balc�o de Recep��o_ � m�o. Voc� pode encontrar uma _Recep��o_ no _Painel Interior_. Voc� lembra como colocar os itens para equipar e decorar seu restaurante, certo?

Agora coloque uma _Recep��o_ perto da entrada do seu restaurante.  Continuaremos com o treinamento depois.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Este tamb�m � o momento ideal para explicar como girar, mover e excluir itens. Observe os dois bot�es redondos pr�ximos ao final da _interface interna_? Eles s�o os bot�es _Ajustar itens_ e _Excluir itens_. Se voc� deseja _Ajustar_ um item, simplesmente _clique com o bot�o esquerdo_ no bot�o _Ajustar Itens_. Voc� notar� que o cursor muda para refletir isso. Em seguida, _clique com o bot�o esquerdo_ no item que deseja ajustar e mova-o para onde deseja que ele fique. Se voc� quiser _girar_ um item, _clique com o bot�o esquerdo_ e _mantenha pressionado_ o bot�o do mouse enquanto gira o mouse. Voc� ver� o item girar tamb�m.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Para _Excluir_ um item, _clique com o bot�o esquerdo_ no bot�o _Excluir item_ e, a seguir, _clique duas vezes_ no item que deseja remover das instala��es do seu restaurante.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Bom! Agora vamos voltar ao _Staff Panel_ e ver o que alguns dos outros bot�es fazem.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Vamos come�ar com o bot�o _List Mode_. O modo de lista mostra uma lista de todos os seus funcion�rios. Aqui voc� pode dar uma olhada r�pida em sua lista de funcion�rios contratados e tamb�m identificar rapidamente quaisquer cargos faltantes para facilitar seu processo de contrata��o.
[POSITION]180,340
[DIMENSION]600,400
[HINT]173,203,200,229

[MESSAGE]Observe os dois pequenos �cones � direita de cada cargo de funcion�rio, completos com barras de classifica��o ao lado do nome de cada funcion�rio. O �cone da medalha representa a reputa��o do chef ou o n�vel de habilidade da equipe, e o �cone da bandeira representa o moral dos funcion�rios. Aqui voc� pode ver rapidamente quem est� com baixo moral ou reputa��o. Se voc� _clicar com o bot�o esquerdo_ em qualquer um desses nomes, voc� retornar� � visualiza��o detalhada. Vamos, vamos tentar isso agora. _Clique com o bot�o esquerdo_ na pessoa que voc� contratou como porteiro de cozinha.
[POSITION]180,340
[DIMENSION]600,400
[HINT]118,110,154,129

[MESSAGE]Agora voc� est� de volta � visualiza��o detalhada. A maioria dos bot�es j� est� dispon�vel. Voc� j� deve estar familiarizado com os dois primeiros bot�es.

Os outros bot�es s�o _Aumentar/Diminuir Sal�rio_, _Transferir Pessoal_ e _Fire Staff_.

Esses bot�es s�o relativamente f�ceis de entender; Vou deixar voc� brincar com isso quando quiser.

Quando terminar de se familiarizar com esses bot�es, _clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]180,340
[DIMENSION]600,400
[HINT]170,202,204,330

[MESSAGE]Bom trabalho! Voc� est� quase pronto para come�ar a receber pedidos em seu primeiro restaurante!

Para abrir seu restaurante rec�m-equipado, _clique com o bot�o esquerdo_ no bot�o _Abrir/Fechar Restaurante_ para come�ar sua carreira como dono de restaurante!
[POSITION]475,32
[DIMENSION]310,250
[HINT]170,202,204,330

[MESSAGE]Agora � s� ter paci�ncia e os clientes certamente entrar�o...

Se voc� estiver impaciente, voc� sempre pode acelerar a velocidade do jogo _clicando com o bot�o esquerdo_ em uma das quatro barras de _Velocidade_ para aumentar ou diminuir a velocidade do jogo. V� em frente - experimente agora.

Quando terminar de experimentar as configura��es de velocidade, _clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]20,28
[DIMENSION]765,250
[HINT]418,569,483,592

[MESSAGE]O bot�o redondo � esquerda dos bot�es _Speed_ � o bot�o _Pause/Resume Game_. _Clique com o bot�o esquerdo_ no bot�o para _Pausar_ primeiro e, em seguida, _clique com o bot�o esquerdo_ novamente para _Retomar_ o jogo.
[POSITION]475,32
[DIMENSION]310,250
[HINT]418,569,483,592

[MESSAGE]H� algo que voc� deve saber sobre as configura��es de velocidade e como o tempo passa no universo dos restaurantes. Para progredir mais r�pido, � simulado o tempo de um m�s com base no desempenho do seu restaurante no final do primeiro dia de cada m�s.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Agora gostaria de explicar sobre a interface do _Centro de Informa��es_. Esta interface pode ajud�-lo a gerenciar melhor este e todos os seus pr�ximos restaurantes.

Vamos abrir a interface agora, certo? _Clique com o bot�o esquerdo_ no bot�o _Centro de Informa��es_.
[POSITION]475,32
[DIMENSION]310,250
[HINT]58,561,96,597

[MESSAGE]Olhando a coluna de bot�es, podemos ver, de cima para baixo: os bot�es _Report Management_, _Report List_, _Report_ e _Goal_. A maioria das fun��es do _Centro de Informa��es_ s�o autoexplicativas. Os mais importantes que voc� deve saber por enquanto s�o os bot�es _Report_ e _Goal_, ent�o vamos dar uma olhada em suas fun��es.

Para continuar, _clique com o bot�o esquerdo_ no bot�o _Relat�rio_.
[POSITION]475,32
[DIMENSION]310,250
[HINT]105,133,144,364

[MESSAGE]Agora d� uma olhada na linha superior de bot�es. Existem, da esquerda para a direita, os bot�es _Avalia��es de Restaurantes_, _Relat�rio de Vendas_, _Estat�sticas_, _Declara��es de Resultados_, _Gr�ficos Financeiros_ e _Reclama��es_. Clique em cada um deles e conhe�a os diferentes tipos de informa��o apresentados.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ quando estiver pronto para continuar.
[POSITION]40,407
[DIMENSION]720,180
[HINT]265,118,502,153

[MESSAGE]Agora volte para o bot�o _Classifica��es de restaurantes_. Isso indica o desempenho do seu restaurante em cada categoria de classifica��o. As categorias com vantagens somam pontos, enquanto as desvantagens subtraem pontos da avalia��o geral do restaurante.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ quando estiver pronto para continuar.
[POSITION]203,410
[DIMENSION]500,180
[HINT]265,118,502,153

[MESSAGE]Preste aten��o especial �s classifica��es das categorias _Meio Ambiente_ e _Alimenta��o_. Quanto maior o valor do seu restaurante nessas categorias, maior ser� a probabilidade de os clientes escolherem o seu restaurante. Isto �, desde que voc� mantenha o _Pre�o_ e as _Reclama��es_ baixos! Fa�a isso e voc� ter� um restaurante de sucesso em suas m�os!
[POSITION]203,410
[DIMENSION]500,180
[HINT]265,118,502,153

[MESSAGE]Quando estiver pronto para seguir em frente, _clique com o bot�o esquerdo_ no bot�o _Meta_ para continuar.
[POSITION]203,480
[DIMENSION]500,180
[HINT]210,246,644,279

[MESSAGE]Como voc� pode ver, a linha superior de bot�es agora exibe o _Pontua��o do jogo_, bem como os bot�es _Objetivo_ do cen�rio. Clique no bot�o _Meta_. Lembra dos seus objetivos? Se voc� esquecer deles, d� uma olhada aqui. Voc� pode ver o que eles s�o e qu�o perto voc� est� de conhec�-los.

_Clique com o bot�o esquerdo_ no bot�o _Meta_ quando estiver pronto para continuar.
[POSITION]203,410
[DIMENSION]500,180
[HINT]265,118,342,153

[MESSAGE]Uau - todo esse gerenciamento de restaurante me deixou com muita fome, Armand. Mas a boa not�cia � que agora voc� tem todas as pe�as necess�rias para come�ar a operar seu restaurante totalmente funcional! Talvez um dia o seu restaurante n�o esteja apenas repleto de funcion�rios eficientes, mas tamb�m de clientes satisfeitos!

Agora vamos l� - _lembre-se, sua meta � alcan�ar 35 clientes com uma receita mensal de US$ 30.000 em tr�s meses._ Voc� acha que consegue fazer isso? Eu certamente acho que voc� pode! Boa sorte!
[POSITION]350,354
[DIMENSION]450,250
[HINT]

