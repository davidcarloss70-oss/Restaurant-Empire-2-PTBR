[MESSAGE]Armand, esta � a arena de culin�ria. Existe um em cada cidade. � aqui que os maiores chefs do mundo travam batalhas na sua luta pela supremacia culin�ria no universo dos restaurantes. Vou orient�-lo neste primeiro concurso de culin�ria e n�o posso garantir que voc� vencer�, mas ajudarei o melhor que puder para ajud�-lo a superar seu "medo do palco" inicial.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]1,25
[DIMENSION]200,250

[MESSAGE]A primeira coisa a fazer � participar do concurso de culin�ria. Como voc� pode ver, este e todos os concursos de culin�ria t�m requisitos diferentes, seja o valor da inscri��o, o tipo de cozinha a ser preparada, ou a quantidade de chefs que ir�o participar, entre outros fatores.

Voc� se qualifica para este concurso de culin�ria, ent�o por que n�o come�a sua ascens�o gradual na escala do chefdom? Para se inscrever neste concurso de culin�ria, _clique com o bot�o esquerdo_ onde diz _Inscreva-se agora_.
[POSITION]1,25
[DIMENSION]200,250

[MESSAGE]E vamos l�! � isso! � aqui que voc� ver� e ouvir� milhares de f�s torcendo por voc� - bem, talvez n�o milhares no in�cio - os primeiros concursos est�o nos degraus mais baixos da escala, mas � medida que voc� come�a a ganhar mais e mais concursos de culin�ria, voc� notar� mais e mais f�s assistindo ao espet�culo.

O painel � sua frente � onde voc� pode selecionar o chef ou chefs que participar�o do concurso. Como voc� � praticamente um ex�rcito de um homem s� nesta fase da sua carreira, n�o h� muito por onde escolher. Mas gostaria de salientar uma ou duas coisas que o ajudar�o a escolher melhor os participantes para concursos futuros.

Para continuar, _clique com o bot�o esquerdo_ em voc� mesmo.
[POSITION]0,240
[DIMENSION]340,250

[MESSAGE]Agora n�o s� temos um close de voc�, Armand, mas tamb�m podemos ver que tipo de culin�ria e habilidades de receita voc� traz para a mesa - desculpe o trocadilho. As _Habilidades de Receita_ mostram os tipos de receitas que voc� sabe preparar. Se voc� notar a pequena barra vertical que precede cada receita, poder� ver que esta barra indica sua profici�ncia para preparar aquela receita. At� agora voc� n�o � muito bom em preparar receitas, mas tudo bem � voc� acabou de se formar!

Agora procure uma de suas receitas na lista. Observe como suas habilidades de prepara��o variam de receita para receita, mesmo que apenas marginalmente? Recomendo que voc� use sempre as receitas que voc� tem mais habilidade, pois isso tende a garantir pontos mais altos.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]0,240
[DIMENSION]350,250

[MESSAGE]Agora vamos dar uma olhada nas _Habilidades Culin�rias_ que voc� possui. Voc� acabou de se formar em uma academia de culin�ria francesa, ent�o nem � preciso dizer que suas habilidades na culin�ria francesa s�o consideravelmente superiores �s suas habilidades na culin�ria americana e italiana, conforme indicado pelas barras amarelas. Como voc� pode ver, suas habilidades no _Curso Principal de Franc�s_ s�o seu trunfo mais forte. Don ainda n�o se preocupe com sua falta de habilidade nessas duas cozinhas - afinal, esta � uma competi��o de culin�ria francesa!

Para continuar, _clique com o bot�o esquerdo_ no bot�o _Entrar no concurso_.
[POSITION]0,240
[DIMENSION]340,250

[MESSAGE]E agora vamos ver quem s�o os concorrentes! Cada chef far� a sua entrada na plataforma de cozinha. Voc� pode visualizar cada concorrente conforme eles se aproximam da plataforma ou simplesmente _clicar com o bot�o esquerdo_ para avan�ar para o pr�ximo chef.

Para continuar, _clique com o bot�o esquerdo_ v�rias vezes para pular a introdu��o do chef. Ou espere at� minha pr�xima mensagem.
[POSITION]0,32
[DIMENSION]310,250

[MESSAGE]Agora voc� est� bem no meio da plataforma, junto com os outros chefs participantes. � quando voc� escolhe as receitas que podem fazer ou quebrar suas aspira��es vencedoras. Vamos escolher uma receita agora. Para selecionar uma receita para qualquer rodada, _clique com o bot�o esquerdo_ no bot�o _Receitas_.
[POSITION]0,240
[DIMENSION]340,250

[MESSAGE]Como voc� pode ver, aparece a familiar _interface de receitas_, com uma lista das receitas que voc� j� conhece e que s�o relevantes para o concurso. O concurso em que voc� participa aceita apenas receitas francesas, portanto, apenas receitas francesas ser�o exibidas. Se o concurso exigir uma receita espec�fica, somente essa receita ser� exibida. E se voc� n�o tiver uma receita obrigat�ria, fique tranquilo, voc� n�o poder� se inscrever no concurso de culin�ria - voc� n�o cumpriria os requisitos m�nimos e a comiss�o organizadora nem permitiria que voc� participasse!

Mas de qualquer forma, por que voc� n�o experimenta a _Ca�arola Mista de Porco_ neste concurso de culin�ria? Depois de selecionar esta receita, _clique com o bot�o esquerdo_ no bot�o _confirmar_ para continuar.
[POSITION]390,260
[DIMENSION]400,250

[MESSAGE]Observe o salto _go! button_ na parte inferior da tela? Don ainda n�o toquei! Se voc� _clicar com o bot�o esquerdo_ nele, voc� iniciar� a competi��o, mas tenho algumas pequenas coisas para discutir com voc� de antem�o. Primeiro, reserve um tempo para se familiarizar com a _interface do concurso de culin�ria_. A maioria dos itens � autoexplicativa, por isso n�o vou me aprofundar em cada pequeno aspecto. Mas se voc� tiver alguma d�vida sobre qualquer um dos elementos da interface, simplesmente _passe o mouse sobre_ o elemento por um ou dois segundos. Uma mensagem de ajuda aparecer� explicando a finalidade de cada elemento.

Depois de sentir que conhece a interface do concurso de culin�ria, _clique com o bot�o esquerdo_ no bot�o saltitante _ir!_.
[POSITION]180,0
[DIMENSION]400,250

[MESSAGE]E l� vamos n�s! Vamos ver se voc� se sai bem na concorr�ncia, Armand! Se voc� quiser ver o que cada chef est� preparando, _clique com o bot�o esquerdo_ diretamente naquele chef e a c�mera far� um zoom nele. Voc� tamb�m pode girar a c�mera como faria nas vistas da cidade ou do restaurante. Se voc� quiser ver toda a plataforma de culin�ria, _clique com o bot�o esquerdo_ diretamente na pr�pria plataforma.

Voc� pode experimentar agora ou _clicar com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]535,15
[DIMENSION]320,250

[MESSAGE]Enquanto os chefs preparam suas receitas diligentemente, voc� sabia que pode ajud�-los a obter classifica��es mais altas? Observe o bot�o _minijogo_. Se voc� _clicar com o bot�o esquerdo_ neste bot�o, um dos tr�s _minijogos_ aparecer� aleatoriamente. Esses jogos foram projetados para ajudar seu chef a melhorar sua concentra��o, precis�o ou habilidades de organiza��o culin�ria, mas somente se voc� concluir o jogo com sucesso! Ao clicar neste bot�o, uma interface de _minijogo_ aparecer�, com explica��es para mostrar como jogar. Ent�o v� em frente e _clique com o bot�o esquerdo_ no bot�o _minijogo_ agora!
[POSITION]0,240
[DIMENSION]340,250

[MESSAGE]Agora voc� tem a op��o de assistir a competi��o de culin�ria seguir seu curso, ajudar seu chef completando com sucesso outro minijogo ou, se tiver a sensa��o de que vai perder, pode _clicar com o bot�o esquerdo_ no bot�o _sair_. Mas como esta � sua primeira competi��o, Armand, n�o vou deixar voc� desistir. N�s, LeBoeufs, n�o desistemos!

Complete mais _minijogos_ e espere at� que todos os chefs terminem de preparar e apresentar suas cria��es culin�rias para continuar. Ap�s esta rodada, os jurados provar�o a comida e o placar aparecer�. Voc� dever� ent�o ver claramente se ganhou ou perdeu, Armand. Se voc� vencer, melhor ainda - parab�ns! No entanto, se voc� perder, n�o se preocupe. Voc� sempre pode voltar e participar novamente.

Isso � tudo que posso fazer para ajud�-lo neste est�gio inicial de sua carreira, Armand. Boa sorte no concurso de culin�ria e espero que voc� ganhe!
[POSITION]180,0
[DIMENSION]400,250
