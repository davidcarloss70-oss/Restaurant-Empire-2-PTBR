[MESSAGE]Atrav�s dos tutoriais, voc� se familiarizar� com os aspectos b�sicos de administrar seu pr�prio imp�rio de restaurantes!

� importante que voc� preste aten��o nas setas animadas que aparecem na tela, pois elas apontar�o para bot�es importantes ou outros assuntos do tutorial.

Se por algum motivo voc� quiser sair do jogo, pressione a tecla _Esc_ a qualquer momento para acessar o menu do jogo.

_Clique com o bot�o esquerdo_ no _bot�o Avan�ar_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Voc� tamb�m pode _manter_ pressionado_ o bot�o _esquerdo do mouse_ na janela do tutorial e _arrastar_ a caixa do tutorial para qualquer lugar da tela.

V� em frente e experimente e ent�o _clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Como esta � a sua primeira experi�ncia em se tornar um dono de restaurante, come�aremos com calma e subiremos na escada da experi�ncia. Isso suavizar� sua curva de aprendizado. Mais tarde, voc� ter� a chance de transformar sua opera��o de restaurante �nico em um conglomerado multinacional!

_Clique com o bot�o esquerdo_ no _bot�o Avan�ar_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Voc� est� atualmente na visualiza��o da cidade. Voc� pode percorrer a cidade movendo o mouse at� as bordas da tela ou usando as setas do teclado.  V� em frente - d� uma olhada no Paree gay!

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Voc� tamb�m pode observar a cidade de diferentes �ngulos e perspectivas.  _Mantenha pressionado o bot�o direito do mouse_ enquanto _move o mouse para a esquerda ou para a direita_.  Isso girar� a visualiza��o. Se voc� quiser alterar a perspectiva de visualiza��o ou o �ngulo da c�mera, simplesmente _mova o mouse para cima ou para baixo_ enquanto _mant�m pressionado o bot�o direito do mouse_.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Para aumentar ou diminuir o zoom da cidade, _segure o bot�o direito do mouse_ e _pressione_ a tecla _Shift_. Ent�o _mova o mouse para longe de voc�_ ou _mova o mouse em sua dire��o_ para ver a cidade de perto ou � dist�ncia. Se voc� tiver um mouse mais recente com roda de rolagem, tamb�m poder� girar a roda para frente ou para tr�s para aumentar e diminuir o zoom.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Enquanto estamos nisso, vamos dar uma olhada em alguns itens na barra de menu superior.

Existem duas exibi��es num�ricas � esquerda da barra de menu superior. O display mais � esquerda � o indicador _Cash_. Isso mostra a quantidade total de dinheiro que voc� tem dispon�vel.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]0,0,104,22

[MESSAGE]O pr�ximo � o indicador _Profit_, que mostra quanto dinheiro voc� realmente ganhou no m�s passado. Tome cuidado! Se voc� vir os n�meros exibidos em vermelho, significa que est� perdendo dinheiro - voc� deve tomar medidas corretivas imediatamente antes que todo o seu suado dinheiro se esgote!

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]142,0,243,22

[MESSAGE]Agora vamos ao seu restaurante. A �rea indicada pelas setas � o _Indicador do Restaurante_. Depois de come�ar a possuir mais e mais restaurantes, voc� pode usar os bot�es quadrados de _seta_ para percorrer os diferentes restaurantes que possui.

Para entrar no Treize � table, _clique com o bot�o esquerdo_ em qualquer um dos bot�es de seta localizados nas laterais do _Indicador de restaurante_ na parte superior da tela.
[POSITION]475,32
[DIMENSION]310,250
[HINT]304,0,590,22

[MESSAGE]Esta � a vista interna do seu restaurante. Se voc� quiser sair do restaurante, _clique com o bot�o esquerdo_ no bot�o _Sair do restaurante_. Isso o levar� para fora do restaurante e de volta � vista da cidade. V� em frente e experimente.
[POSITION]475,32
[DIMENSION]310,250
[HINT]568,2,588,22

[MESSAGE]Voc� tamb�m pode _clicar duas vezes_ em qualquer restaurante de sua propriedade para entrar. Experimente.
[POSITION]475,32
[DIMENSION]310,250
[HINT]568,2,588,22

[MESSAGE]Se voc� tiver d�vidas sobre a fun��o de um bot�o, simplesmente _passe o mouse sobre_ o bot�o ou um elemento da interface. Um breve pop-up descrevendo o bot�o ou fun��o da interface aparecer�. A ajuda estendida ser� exibida se voc� _passar o mouse_ sobre o bot�o um pouco mais.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Seus clientes gostam de olhar objetos interessantes enquanto comem. A decora��o acrescenta ambiente � experi�ncia gastron�mica, por isso vamos tornar o seu restaurante mais atraente. _Clique com o bot�o esquerdo_ no bot�o _Painel Interior_ quando estiver pronto para a pr�xima etapa.
[POSITION]510,32
[DIMENSION]310,250
[HINT]550,559,588,598


[MESSAGE]Estas s�o as principais categorias de itens que voc� pode colocar em seus restaurantes. Existem _Arranjos de assentos_, _Decora��o_, _Quartos e Texturas_, _Ilumina��o_ e _Acess�rios_. Clicar em qualquer um desses bot�es exibir� a categoria do item, bem como suas subcategorias. Vamos apimentar as coisas neste restaurante tristemente ins�pido agora, certo? _Clique com o bot�o esquerdo_ no bot�o _Decora��o_ para continuar.
[POSITION]510,32
[DIMENSION]310,250
[HINT]147,377,308,414

[MESSAGE]Existem subcategorias _Montado na parede_, _Montado no ch�o_ e _Montado na mesa_. Por enquanto, vamos nos concentrar nos itens _montados na parede_ - o bot�o j� est� destacado em amarelo.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ quando estiver pronto para a pr�xima etapa.
[POSITION]510,32
[DIMENSION]310,250
[HINT]372,383,473,411

[MESSAGE]Todos os itens de decora��o possuem pelo menos um atributo e no m�ximo dois. Alguns aumentam a classifica��o de conforto de um restaurante, enquanto outros podem aumentar a classifica��o de decora��o do seu restaurante. Eles s�o indicados pelas barras de atributos correspondentes. Atributos com classifica��o mais alta s�o caracter�sticas desej�veis ??e, quanto mais altas forem suas classifica��es, mais beneficiar�o as classifica��es do seu restaurante.

Escolha um item para colocar em seu restaurante agora _clicando com o bot�o esquerdo_ na miniatura de um item.
[POSITION]510,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Agora arraste o objeto em sua m�o para o ch�o do restaurante. Voc� v� uma caixa colorida abaixo do item? Essa � a caixa delimitadora do item � o espa�o f�sico que o item que voc� est� segurando ocupa. Voc� n�o pode colocar o item quando a caixa estiver vermelha. Alinhe o item contra uma parede. Donn�o se preocupe se o item n�o estiver alinhado corretamente - os itens se alinhar�o corretamente quando estiverem pr�ximos a uma parede.

Observe que a mensagem de ajuda que aparece perto do topo da tela indicar� quando um item pode ser colocado. Encontre um local para adicionar este item e _clique com o bot�o esquerdo_ para mont�-lo.
[POSITION]510,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Enquanto voc� faz isso, coloque mais alguns itens nas paredes. Quando voc� sentir que pegou o jeito, _clique com o bot�o esquerdo_ no bot�o _Avan�ar_.
[POSITION]510,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Bom trabalho! Agora que existem mais alguns itens colocados nas paredes do seu restaurante, vamos ver o que podemos fazer com o ch�o. _Clique com o bot�o esquerdo_ no bot�o _Montado no ch�o_. Isso abrir� os itens de decora��o dispon�veis que podem ser colocados no ch�o.
[POSITION]510,32
[DIMENSION]310,250
[HINT]407,386,438,408

[MESSAGE]Colocar itens no ch�o de um restaurante � semelhante a montar itens nas paredes. Escolha alguns itens que lhe agradem e coloque-os no ch�o do restaurante.

Quando estiver satisfeito com a quantidade de decora��o que voc� tem em seu restaurante, _clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]510,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Voc� obviamente aprende r�pido! Lembre-se, sempre que precisar de ajuda, voc� pode me procurar. Simplesmente _clique com o bot�o esquerdo_ no bot�o _Modo Aventura_ no canto inferior esquerdo da tela. A interface do modo aventura aparecer�. _Tudo o que voc� precisa fazer depois deste tutorial � localizar minha casa na lista de locais e clicar duas vezes em meu nome (aquele que diz "Michel casa de LeBoeuf")._ Estarei esperando por voc� l� para que possamos continuar seu curso intensivo em gest�o de restaurantes!

Vejo voc� em breve!
[POSITION]510,32
[DIMENSION]310,250
[HINT]2,563,37,594

