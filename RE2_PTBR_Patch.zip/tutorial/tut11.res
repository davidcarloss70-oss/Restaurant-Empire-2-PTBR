[MESSAGE]Vamos falar sobre est�gios e como voc� pode oferec�-los aos seus chefs.

Ao oferecer est�gios, seus aprendizes podem aprender gradualmente com a habilidade e sabedoria de receita de Armand e eventualmente se tornarem t�o habilidosos quanto ele.

Vamos dar uma olhada nisso abrindo o _Staff Panel_.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]No _Staff Panel_, voc� pode escolher o chef que deseja selecionar como seu aprendiz. V� em frente e tente oferecer um est�gio para "%s %s".
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Armand pode oferecer no m�ximo tr�s chefs para se tornarem seus aprendizes. Se voc� j� tem tr�s e gostaria de oferecer a oportunidade a outro chef, voc� pode encerrar o relacionamento com um de seus aprendizes atuais e ent�o oferecer a vaga vazia ao novo chef.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Excelente! Agora que voc� aprendeu como ter chefs sob sua prote��o, voc� pode ir em frente e brincar um pouco mais. Quem sabe? Um futuro chef estrela pode estar em um deles!
[POSITION]475,32
[DIMENSION]310,250
[HINT]
