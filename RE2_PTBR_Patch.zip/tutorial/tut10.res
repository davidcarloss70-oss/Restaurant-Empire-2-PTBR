[MESSAGE]O que temos aqui? Parece que voc� acabou de encontrar um novo parceiro de neg�cios. Vamos dar uma olhada no que seu novo fornecedor de m�veis pode lhe oferecer.

Para fazer isso, abra a _Lista de Fornecedores de M�veis_ que est� localizada na _Lista de Relat�rios_ do _Centro de Informa��es._
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]A _Lista de Fornecedores de M�veis_ mostra um cat�logo de todos os contatos de fornecedores de m�veis que voc� possui. Para conferir os dados de cada fornecedor, basta destacar o fornecedor e seus produtos ser�o revelados na parte inferior da janela. Clicar nos bot�es esquerdo e direito encontrados nas laterais do cat�logo permitir� que voc� navegue por toda a cole��o.

Observe que uma vez adicionado um fornecedor � lista de fornecedores, todos os itens oferecidos por essa empresa s�o automaticamente adicionados ao _Painel Interior_.
[POSITION]475,32
[DIMENSION]310,250
[HINT]
