[MESSAGE]Se voc� deseja se destacar mais em concursos de culin�ria ou espera conquistar mais clientes, precisar� aprender a ampliar seus conhecimentos sobre alimenta��o por meio de pesquisas.

Voc� pode realizar pesquisas acessando o painel _Recipe Research_ encontrado na guia _Report Management_ do _Information Center_.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]No painel _Pesquisa de receita_, voc� pode definir quanto dinheiro deseja investir na pesquisa de um tipo de receita espec�fico, modificando as barras na coluna _Gastos mensais_. Colocar mais dinheiro em pesquisa aumentar� naturalmente sua efici�ncia nessa categoria; mas � claro que tamb�m tornar� mais dif�cil equilibrar as despesas do restaurante.

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]A coluna de progresso posicionada ao lado da coluna de gastos mensais mostra o progresso atual de sua pesquisa. Quando uma barra atingir o m�ximo, uma nova receita ser� adicionada � sua sele��o de receitas e a nota de pesquisa desse tipo espec�fico de receita tamb�m melhorar�. Al�m disso, depois de concluir a pesquisa m�xima com nota 5, uma receita definitiva ser� desbloqueada para voc�!

Observe que executar v�rios projetos de pesquisa ao mesmo tempo diminuir� a efici�ncia geral da pesquisa.
[POSITION]475,32
[DIMENSION]310,250
[HINT]
