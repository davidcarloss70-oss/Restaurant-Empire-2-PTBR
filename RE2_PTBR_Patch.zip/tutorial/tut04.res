[MESSAGE]Vou falar com voc�s sobre as nuances de um segundo andar. Ter um segundo andar significa que voc� pode acomodar aproximadamente o dobro do n�mero de clientes. Isso tamb�m significa que o tempo que leva para entregar a comida desde a cozinha leva aproximadamente o dobro - e nada corre o risco de incomodar mais um cliente do que um prato quente servido frio!

Tentaremos minimizar o tempo de entrega. _Clique com o bot�o esquerdo_ no ch�o da cozinha do restaurante para continuar.
[POSITION]475,50
[DIMENSION]400,250
[HINT]

[MESSAGE]Agora _clique com o bot�o esquerdo_ no _Painel Interior_. Observe como o _Painel Interior_ agora mostra apenas itens relacionados � cozinha? O _Painel Interior_ mostrar� apenas itens relevantes para cada ambiente. Sua cozinha vem equipada com quase tudo que voc� precisa, mas faltam alguns itens que voc� precisar� para equipar totalmente sua cozinha. Um deles � o _gar�om burro_.

Encontre o _gar�om burro_ entre as miniaturas dos itens da cozinha e adicione-o em um espa�o vazio dispon�vel, ent�o _clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,50
[DIMENSION]400,250
[HINT]446,415,496,471

[MESSAGE]Bom! J� que estamos na cozinha, reserve um tempo para examinar as instala��es de cozinha dispon�veis no _painel interno_ com as quais voc� trabalhar� durante sua carreira como chef e leia a descri��o de cada instala��o.
[POSITION]475,32
[DIMENSION]310,250
[HINT]

[MESSAGE]Preste aten��o especial � _Esta��o de Espera_. Todo restaurante precisa de pelo menos um na cozinha. Como a _Esta��o de Espera_ � onde os gar�ons pegam a comida para entrega, n�o colocar uma significa que nenhuma comida ser� entregue! Treize � table j� tem um na cozinha, ent�o n�o h� necessidade de adicionar aqui. No entanto, certifique-se de colocar uma _Esta��o de Espera_ em qualquer cozinha que voc� montar no futuro!

_Clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,50
[DIMENSION]400,250
[HINT]

[MESSAGE]Agora, suba as escadas _clicando com o bot�o esquerdo_ no bot�o _subir/descer_.
[POSITION]475,50
[DIMENSION]400,250
[HINT]

[MESSAGE]Procure o po�o do _gar�om burro_ no andar de cima. Sempre que um cliente estiver jantando no andar de cima, � aqui que a comida ser� entregue na cozinha do andar de baixo. Instalar um elevador � �til, pois geralmente reduz 50% do tempo total de entrega.

Agora veremos alguns recursos adicionais encontrados na _interface do item_. Primeiro, abra o _painel interno_ se ainda n�o o fez.
[POSITION]475,50
[DIMENSION]400,250
[HINT]

[MESSAGE]Agora _clique com o bot�o esquerdo_ no bot�o _disposi��o dos assentos_. Isso mostrar� os arranjos de assentos de _conjuntos de mesas pequenas_ dispon�veis quando voc� abri-lo pela primeira vez.
[POSITION]475,50
[DIMENSION]400,250
[HINT]373,386,407,409

[MESSAGE]Voc� est� vendo as combina��es de cadeiras e mesas dispon�veis para este tipo de restaurante. O bot�o destacado mostra conjuntos de mesas de dois lugares, completos com atributos de conforto, descri��o e pre�o. Vamos adicionar alguns conjuntos. Adicionar conjuntos de mesa � semelhante a adicionar decora��es no ch�o � voc� se lembra da nossa primeira li��o, certo?

Quando terminar de adicionar conjuntos de cadeiras e mesas, _clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]475,50
[DIMENSION]400,250
[HINT]373,386,407,409

[MESSAGE]Tamb�m est�o dispon�veis mesas de quatro lugares, �teis para grupos maiores de clientes. _Clique com o bot�o esquerdo_ na subcategoria _conjuntos de tabelas grandes_. Voc� ver� as op��es dispon�veis. Escolha um conjunto e adicione alguns no ch�o, embora seja melhor adicionar a mesma combina��o cadeira/mesa para dar consist�ncia ao seu layout.

Quando terminar de adicionar conjuntos de cadeiras grandes, _clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]445,60
[DIMENSION]430,250
[HINT]373,386,407,409

[MESSAGE]Ali�s, se voc� n�o percebeu, alguns itens, principalmente os jogos de mesa e os utens�lios de cozinha, possuem uma caixa delimitadora azul e tamb�m verde. Clientes e funcion�rios ocupam a �rea azul dos itens para interagir com eles. Donn�o bloqueie essas �reas, caso contr�rio sua equipe n�o poder� usar as instala��es da cozinha e os clientes n�o poder�o sentar-se para desfrutar de uma refei��o!

Aqui est� uma regra: se voc� n�o conseguir colocar um item em seu restaurante, basta olhar a mensagem de ajuda exibida na parte superior da tela. Ele lhe dir� por que voc� n�o pode coloc�-lo.

Quando terminar de preencher a sala com assentos, cadeiras e decora��o, _clique com o bot�o esquerdo_ no bot�o _menu de receitas_ para continuar.
[POSITION]445,60
[DIMENSION]400,250
[HINT]407,386,438,408

[MESSAGE]Percorra algumas receitas e preste aten��o ao campo _requires_. Viu como os �cones mudam a cada receita? Se voc� vir um �cone, significa que voc� precisa daquela cozinha para fazer aquela receita. Se estiver sobre fundo verde, significa que voc� j� possui aquele item em sua cozinha; sobre um fundo vermelho, significa que voc� precisa adicionar esse item antes de preparar aquela receita espec�fica.

_Clique com o bot�o esquerdo_ no bot�o _pr�ximo_ para continuar.
[POSITION]475,50
[DIMENSION]400,250
[HINT]91,383,197,427

[MESSAGE]Procure a receita de _Crepes Marcie_. Est� em _Sobremesas_. Voc� notar� que esta receita requer um _processador de alimentos_ para seu preparo. Se voc� planeja oferecer este prato suculento, ser� necess�rio adicionar o _processador de alimentos_ para preparar esta receita, caso contr�rio os chefs n�o ter�o as instala��es necess�rias para preparar a receita. Receitas diferentes t�m requisitos de instala��o diferentes, portanto, certifique-se de ter os itens necess�rios em vigor!

Agora des�a. H� mais coisas que tenho para lhe mostrar.
[POSITION]475,50
[DIMENSION]400,250
[HINT]

[MESSAGE]_Clique com o bot�o esquerdo_ no ch�o da cozinha do restaurante. O _processador de alimentos_ deve ser colocado em uma _mesa de prepara��o_, ent�o v� em frente e coloque-o. _Fornos de microondas_ tamb�m s�o colocados na _mesa de prepara��o_.

Quando terminar de colocar os itens necess�rios em sua cozinha, _clique com o bot�o esquerdo_ no bot�o _menu de receitas_ para continuar.
[POSITION]475,50
[DIMENSION]400,250
[HINT]

[MESSAGE]Vamos dar uma olhada em como voc� pode alterar a qualidade geral de uma receita. Observe a coluna _Ingredientes Essenciais_? Estas s�o as configura��es padr�o para cada receita. Todas as receitas v�m com ingredientes de qualidade tr�s estrelas, a classifica��o de qualidade m�xima para _Ingredientes Essenciais_. Voc� pode ajustar a qualidade de um ingrediente se primeiro _passar o mouse sobre_ as estrelas do ingrediente que deseja ajustar. Voc� notar� uma caixa cinza delineando as estrelas, junto com os bot�es _esquerda_ e _seta direita_. Se voc� clicar neles, poder� ajustar os ingredientes para uma qualidade superior ou inferior.

Quando terminar de ajustar, _clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]180,340
[DIMENSION]600,400
[HINT]360,98,701,289

[MESSAGE]Voc� deve estar se perguntando qual � o prop�sito de rebaixar a qualidade de uma receita. Primeiro, o seu restaurante pode n�o ter uma classifica��o muito alta. Se voc� preparar comida de primeira qualidade em um restaurante comum, os clientes n�o esperar�o pagar tanto pelas refei��es. Isso causar� muitos clientes irados! Da mesma forma, se voc� tiver uma classifica��o muito alta no restaurante, os clientes ficar�o irritados com a m� qualidade da comida do restaurante.

O segredo est� em equilibrar a qualidade da sua receita com a avalia��o do restaurante, ent�o por que n�o experimenta agora? Ajuste a qualidade de uma receita para que ela tenha uma classifica��o de receita de um v�rgula cinco estrelas.
[POSITION]368,320
[DIMENSION]430,400
[HINT]360,98,701,289

[MESSAGE]Quanto mais restaurantes voc� tiver atendendo a diferentes or�amentos de clientes, mais voc� precisar� ajustar a qualidade de uma receita. Todo esse ajuste fino pode sair do controle rapidamente - � por isso que existe o bot�o _Duplicar receita_. Quando terminar de ajustar uma receita, _clique com o bot�o esquerdo_ no bot�o _Duplicar receita_. Uma mensagem pop-up aparecer� indicando que a receita foi duplicada. Donn�o se esque�a de ajustar o _Pre�o do Menu_ da receita para se adequar � nova classifica��o!

Depois de duplicar uma receita, _clique com o bot�o esquerdo_ no bot�o _Avan�ar_ para continuar.
[POSITION]550,32
[DIMENSION]240,200
[HINT]206,458,242,494

[MESSAGE]Excelente! Agora voc� sabe como economizar o tempo de entrega de alimentos, bem como os diferentes requisitos de receitas e o uso de diferentes itens de cozinha. E voc� n�o s� sabe como alterar a qualidade dos ingredientes de uma receita, mas tamb�m como configurar o layout do piso. O mais importante � que agora voc� tem um restaurante totalmente utilizado. Parab�ns - voc� percorreu um longo caminho!

Antes de deix�-lo sozinho, quero lembr�-lo que _sua meta � atingir uma receita mensal de US$ 40.000 e 50% de suas refei��es devem ser servidas na hora certa. Voc� tem tr�s meses para atingir essas metas. Boa sorte!
[POSITION]475,32
[DIMENSION]310,250
[HINT]
