m_fur_dn
Arranjos de assentos
Clique com o bot�o esquerdo para adicionar mesas e cadeiras ao seu restaurante.
~
s_lts_dn
Conjuntos de mesa grandes
Clique com o bot�o esquerdo para adicionar mesas grandes ao seu restaurante.
~
s_sts_dn
Conjuntos de mesa pequena
Clique com o bot�o esquerdo para adicionar pequenos conjuntos de mesas ao seu restaurante.
~
m_dec_dn
Decora��o
Clique com o bot�o esquerdo para dar vida ao seu restaurante com uma decora��o atraente.
~
s_wm_dn
Decora��o de parede
Clique com o bot�o esquerdo para decorar as paredes do seu restaurante com itens montados na parede.
~
s_fp_dn
Decora��o montada no ch�o
Clique com o bot�o esquerdo para decorar o ch�o do seu restaurante com itens montados no ch�o.
~
s_tm_dn
Decora��o montada em mesa
Clique com o bot�o esquerdo para decorar as mesas do seu restaurante com itens montados na mesa.
~
m_lg_dn
Ilumina��o
Ilumine seu restaurante com lumin�rias.
~
s_lw_dn
Ilumina��o montada na parede
Clique com o bot�o esquerdo para adicionar ilumina��o de parede ao seu restaurante.
~
s_lf_dn
Ilumina��o montada no ch�o
Clique com o bot�o esquerdo para adicionar ilumina��o montada no ch�o ao seu restaurante.
~
s_lt_dn
Ilumina��o montada em mesa
Clique com o bot�o esquerdo para adicionar ilumina��o montada na mesa ao seu restaurante.
~
m_oth_dn
Acess�rios
Clique com o bot�o esquerdo para adicionar acess�rios ao seu restaurante.
~
s_rcp_dn
Balc�es de recep��o
Clique com o bot�o esquerdo para adicionar balc�es de recep��o para suas recepcionistas.
~
s_pf_dn
Est�gios de desempenho
Clique com o bot�o esquerdo para adicionar est�gios de performance para seus artistas.
~
m_raw_dn
Quartos e Texturas
Clique com o bot�o esquerdo para reorganizar, redistribuir e redesenhar a planta do seu restaurante.
~
s_roo_dn
Adicionar salas
Clique com o bot�o esquerdo para adicionar uma sala ao seu restaurante.
~
s_wal_dn
Alterar design de parede
Clique com o bot�o esquerdo para alterar o design da parede do seu restaurante.
~
s_flo_dn
Alterar padr�o de piso
Clique com o bot�o esquerdo para alterar o padr�o do piso do seu restaurante.
~
aitem_dn
Ajustar itens
Clique com o bot�o esquerdo para mover e girar itens.
~
ditem_dn
Excluir itens
Clique com o bot�o esquerdo para excluir um item do seu restaurante.
~
aroom_dn
Ajustar salas
Clique com o bot�o esquerdo para redimensionar e mover salas.
~
droom_dn
Excluir salas
Clique com o bot�o esquerdo para excluir uma sala do seu restaurante.
~
okD
OK
Aplique as altera��es de configura��o e feche a janela.
~
cancelD
Cancelar
Cancelar.
~
de_b_O
Detec��o autom�tica
Defina automaticamente as configura��es de v�deo com base na configura��o do seu sistema.
~
app_b_O
Aplicar
Aplique as altera��es de configura��o agora.
~
tabLOADd
CARREGAR JOGO
Carregue um jogo salvo anteriormente.
~
tabSAVEd
SALVAR JOGO
Salve o jogo atual.
~
tabVIDEd
OP��ES NO JOGO
Altere as configura��es gr�ficas, de som e de interface.
~
deleteDN
Excluir jogo salvo
Clique com o bot�o esquerdo para excluir o jogo salvo selecionado.
~
GraphicD
Detalhe gr�fico
Arraste o controle deslizante para fazer altera��es nos detalhes gr�ficos. Existem tr�s configura��es: baixa, m�dia e alta.
~
DrawDist
Desenhar dist�ncia
Arraste o controle deslizante para fazer altera��es na dist�ncia de desenho. Configura��es mais baixas n�o atrair�o objetos distantes e melhorar�o a velocidade do jogo. Configura��es mais altas desenhar�o objetos distantes, mas poder�o deixar o computador lento.
~
Brightne
Brilho
Arraste o controle deslizante para fazer altera��es no brilho. Configura��es mais baixas produzir�o uma tela mais escura, enquanto configura��es mais altas ir�o iluminar a tela.
~
Filter
Filtragem
Voc� pode escolher entre duas configura��es: filtragem bilinear e trilinear.
~
DynamicL
ILUMINA��O DIN�MICA
Ative ou desative a ilumina��o din�mica.
~
Shadow
SOMBRA
Ative ou desative as sombras.
~
SoundVol
Volume dos efeitos sonoros
Arraste o controle deslizante para aumentar ou diminuir o volume dos efeitos sonoros.
~
MusicVol
Volume da m�sica
Arraste o controle deslizante para aumentar ou diminuir o volume da m�sica.
~
Eax
EAX
Ative ou desative o EAX.
~
ScrollSp
Sensibilidade do mouse
Arraste o controle deslizante para fazer altera��es na sensibilidade do mouse. Configura��es mais altas tornar�o o mouse mais responsivo. Reduza as configura��es se o mouse se mover r�pido demais para sua prefer�ncia.
~
ContextH
Ajuda sens�vel ao contexto
Determine o grau de mensagens de ajuda da interface do jogo que voc� precisa. A ajuda breve exibir� apenas o nome dos elementos da interface, enquanto a ajuda detalhada fornecer� uma breve descri��o de seu uso. Deixe-o desligado se n�o quiser ajuda.
~
flycam
Fly-bys da c�mera
Ative os sobrev�os da c�mera se quiser que a c�mera fa�a zoom entre locais e restaurantes. Desative os fly-bys da c�mera se quiser que a c�mera apare�a em locais e restaurantes.
~
CompCol
Salvar jogo
Indica a cor da sua empresa. Esta � a cor usada para identificar seus restaurantes no minimapa.
~
CampChap
Cap�tulo Cen�rio
Indica o cap�tulo do cen�rio do jogo salvo selecionado.
~
GameDate
Data do jogo
Indica a data atual do jogo salvo selecionado.
~
SaveDate
Salvar data
Indica a data em que o jogo salvo selecionado foi salvo.
~
LoadFile
Carregar jogo
Clique com o bot�o esquerdo para selecionar o jogo salvo. Clique duas vezes para carregar o jogo selecionado.
~
SaveFile
Salvar jogo
Clique com o bot�o esquerdo para selecionar a barra de salvamento do jogo. Clique duas vezes para salvar o jogo atual no slot selecionado. Qualquer jogo salvo anteriormente no mesmo slot ser� exclu�do.
~
ChefPane
PAINEL DO CHEF
Clique com o bot�o esquerdo para mudar para o painel do chef.
~
ChefPDis
PAINEL DO CHEF
Este recurso � desativado quando n�o h� chefs no seu restaurante.
~
WSPane
PAINEL DE GAR�ONS
Clique com o bot�o esquerdo para mudar para o painel do chef.
~
WSPDis
PAINEL DE GAR�ONS
Este recurso � desativado quando n�o h� gar�ons no seu restaurante.
~
HireBut
CONTRATAR EQUIPE
Clique com o bot�o esquerdo para contratar pessoal.
~
HireDis
CONTRATAR EQUIPE
Selecione um restaurante para permitir a contrata��o de pessoal.
~
FireBut
EQUIPE DE BOMBEIROS
Demita a equipe selecionada.
~
TranBut
PESSOAL DE TRANSFER�NCIA
Transferir a equipe selecionada para outro restaurante.
~
OAppBut
OFERECE APRENDIZAGEM
Ofere�a est�gio ao chef selecionado. Os chefs aprendizes recebem aumentos em todas as suas habilidades a cada m�s, o que de outra forma n�o estaria dispon�vel ao trabalhar como chef padr�o.
~
TAppBut
TERMINAR APRENDIZAGEM
Encerrar o aprendizado do chef selecionado.
~
NextChef
PR�XIMA EQUIPE
Clique com o bot�o esquerdo para ver a pr�xima pauta da lista.
~
BackChef
EQUIPE ANTERIOR
Clique com o bot�o esquerdo para ver a pauta anterior na lista.
~
NextRest
PR�XIMO RESTAURANTE (Chave: Espa�o)
Clique com o bot�o esquerdo para ver o pr�ximo restaurante.
~
BackRest
RESTAURANTE ANTERIOR (Tecla: Shift + Espa�o)
Clique com o bot�o esquerdo para ver o restaurante anterior.
~
RaiseSal
AUMENTAR SAL�RIO
Aumentar o sal�rio do funcion�rio selecionado.
~
LowerSal
MENOR SAL�RIO
Reduza o sal�rio do funcion�rio selecionado.
~
AppShow
LISTA DE APETIZADORES
Expanda a lista de aperitivos.
~
SoupShow
LISTA DE SOPA
Expanda a lista de sopas.
~
MainShow
LISTA DE CURSOS PRINCIPAIS
Expanda a lista de cursos principais.
~
DessShow
LISTA DE SOBREMESAS
Expanda a lista de sobremesas.
~
BreShow
LISTA DE CAF� DA MANH�
Expanda a lista de caf� da manh�.
~
Switch
MUDAR PARA O MODO DE LISTA
Clique com o bot�o esquerdo para ver uma lista de funcion�rios sob seu emprego.
~
SwiDis
MUDAR PARA O MODO DE LISTA
Esta fun��o n�o est� dispon�vel no modo de lista.
~
Invent
LISTA DE INVENT�RIO
Exibe o invent�rio do chef selecionado. Clique com o bot�o esquerdo para ver o status do chef.
~
Status
LISTA DE ESTADOS
Exibe o status do chef selecionado. Clique com o bot�o esquerdo para ver as habilidades do chef.
~
Skill
HABILIDADE
Exibe a receita e as habilidades culin�rias do chef selecionado. Clique com o bot�o esquerdo para ver a lista de invent�rio do chef.
~
Repu
REPUTA��O
Indica a reputa��o do membro da equipe.
~
Morale
MORAL
Indica o moral do membro da equipe.
~
Skills
HABILIDADE
Indica as habilidades do membro da equipe.
~
CloseCh
SA�DA
Feche o painel da equipe.
~
assignD
Atribuir Chef
Designe um chef para preparar este curso de comida.
~
chefasds
Atribuir Chef
Voc� deve primeiro selecionar um prato de comida no menu!
~
TitleON
Fonte do t�tulo
Altere a fonte do t�tulo do seu menu.
~
TextON
Fonte do texto
Altere a fonte do texto do seu menu.
~
BackON
Fundo
Altere a imagem de fundo do seu menu.
~
FdViewDe
Ver detalhes
Veja os detalhes da receita selecionada.
~
FdViDeDS
Ver detalhes
Voc� deve primeiro selecionar um prato de comida no menu!
~
berbton
Adicionar bebida
Adicione bebidas ao menu de comida.
~
FdAddRec
Adicionar receita
Adicione uma receita ao menu de comida.
~
FdDelRec
Excluir receita
Exclua uma receita do menu de comida.
~
FdDelRDS
Excluir receita
Voc� deve primeiro selecionar um prato de comida no menu!
~
CopyFdMe
Copiar menu de comida
Copie este menu de comida para outro restaurante.
~
FdNextPg
Pr�xima p�gina
V� para a pr�xima p�gina do menu de comida.
~
FdPrevPg
P�gina anterior
V� para a p�gina anterior do menu de comida.
~
FdSelVie
Ver detalhes
Visualize o menu de comida do restaurante selecionado.
~
FdSelVDS
Ver detalhes
Voc� deve primeiro selecionar um restaurante!
~
FdSelCop
Importar Menu de Comida
Importe o card�pio de comida do restaurante selecionado.
~
FdSelCDS
Importar Menu de Comida
Voc� deve primeiro selecionar um restaurante!
~
FdSelNav
Navegar
Navegue por esta interface.
~
FdExit
Sa�da
~
DupliON
Receita duplicada
Crie uma c�pia da receita selecionada.
~
DeleteON
Excluir receita
Exclua a receita selecionada.
~
TofoodON
Adicionar ao menu de comida
Importe a receita selecionada para o Menu Comida.
~
TofoodDS
Adicionar ao menu de comida
Esta fun��o s� est� dispon�vel quando um restaurante tiver sido selecionado ou dentro de um.
~
FoodMeDn
Ver menu de comida
Veja o menu de comida do restaurante atual.
~
FoodMeDS
Ver menu de comida
Esta fun��o s� est� dispon�vel quando um restaurante tiver sido selecionado ou dentro de um.
~
ExitON
Sa�da
Saia da interface da receita.
~
NextReci
Pr�xima receita
Veja os detalhes da pr�xima receita.
~
PrevReci
Receita Anterior
Veja os detalhes da receita anterior.
~
NextCate
Pr�xima categoria
~
PrevCate
�ltima categoria
~
ReciInPr
Aumentar pre�o
Aumentar o pre�o de venda da receita selecionada.
~
ReciDePr
Diminuir pre�o
Diminuir o pre�o de venda da receita selecionada.
~
ReciCate
Categoria
Selecione outra categoria.
~
breakfDN
Caf� da manh�
Veja as receitas de caf� da manh� dispon�veis atualmente.
~
AppetiON
Aperitivo
Veja as receitas de aperitivos dispon�veis atualmente.
~
DesserON
Sobremesa
Veja as receitas de sobremesas dispon�veis atualmente.
~
MainCoON
Prato principal
Veja as principais receitas de pratos dispon�veis atualmente.
~
SoupON
Sopa
Veja as receitas de sopa dispon�veis atualmente.
~
HotCofDN
Caf� quente
Veja o caf� quente dispon�vel atualmente.
~
IceCofDN
Caf� gelado
Veja o caf� gelado dispon�vel atualmente.
~
TeaDN
Ch�
Veja o ch� dispon�vel atualmente.
~
OthDkDN
Outras bebidas
Veja outras bebidas dispon�veis atualmente.
~
FoodDN
Comida
Veja as receitas de comida dispon�veis atualmente.
~
CakeDN
Bolos, tortas e tortas
Veja as receitas de bolos, tortas e tortas dispon�veis atualmente.
~
PastryDN
Biscoitos e Doces
Veja as receitas de biscoitos e past�is dispon�veis atualmente.
~
SorbetDN
Sorvetes e Soberts
Veja as receitas de sorvetes e soberts dispon�veis atualmente.
~
PubGelDN
Pudins e sobremesa de gelatina
Veja os pudins e sobremesas de gelatina dispon�veis atualmente.
~
BeverDN
Bebidas
Veja as bebidas dispon�veis atualmente.
~
BChef
PAINEL DE PESSOAL (Tecla: F6)
Clique com o bot�o esquerdo para abrir a interface do painel da equipe.
~
BChefD
PAINEL DE PESSOAL
Esta fun��o s� est� dispon�vel quando um restaurante tiver sido selecionado ou dentro de um.
~
BReport
CENTRO DE INFORMA��ES (Tecla: F2)
Clique com o bot�o esquerdo para abrir a interface do centro de informa��es.
~
BMenu
MENU DE COMIDA (Tecla: F4)
Clique com o bot�o esquerdo para abrir a interface do menu de comida.
~
BMenuD
MENU DE COMIDA
Esta fun��o s� est� dispon�vel quando um restaurante tiver sido selecionado ou dentro de um.
~
BRecipe
MENU DE RECEITAS (Tecla: F3)
Abra o menu de receitas.
~
BRecipeD
MENU DE RECEITAS
Esta fun��o s� est� dispon�vel quando um restaurante tiver sido selecionado ou dentro de um.
~
BRest
LISTA DE RESTAURANTES (Tecla: F5)
Abra o painel do restaurante.
~
BCust
PAINEL DE CLIENTES (Tecla: F7)
Clique com o bot�o esquerdo para abrir a interface do painel do cliente.
~
BCustD
PAINEL DE CLIENTES
Esta fun��o s� est� dispon�vel quando um restaurante tiver sido selecionado ou dentro de um.
~
BPlay
PAUSAR JOGO (Tecla: 0 ou P)
Clique com o bot�o esquerdo para pausar o jogo.
~
BStop
RETOMAR JOGO (Tecla: 0 ou P)
Clique com o bot�o esquerdo para continuar o jogo.
~
BSp1
VELOCIDADE 1 (Tecla: 1)
Clique com o bot�o esquerdo para definir a velocidade do jogo para 1.
~
BSp2
VELOCIDADE 2 (Tecla: 2)
Clique com o bot�o esquerdo para definir a velocidade do jogo para 2.
~
BSp3
VELOCIDADE 3 (Tecla: 3)
Clique com o bot�o esquerdo para definir a velocidade do jogo para 3.
~
BSp4
VELOCIDADE 4 (Tecla: 4)
Clique com o bot�o esquerdo para definir a velocidade do jogo para 4.
~
BInter
PAINEL INTERIOR
Clique com o bot�o esquerdo para abrir a interface do painel interno.
~
BFup
V� PARA CIMA (Tecla: PAGE UP)
Clique com o bot�o esquerdo para subir.
~
BFdown
V� PARA BAIXO (Tecla: P�GINA PARA BAIXO)
Clique com o bot�o esquerdo para descer
~
BMap
MINI MAPA (Tecla: M)
Clique com o bot�o esquerdo para ver o minimapa.
~
BOption
OP��ES DE JOGO (chave: ESC)
Abra o menu de op��es do jogo.
~
BAdvent
MODO AVENTURA (Tecla: A)
Clique com o bot�o esquerdo para abrir a interface do modo aventura.
~
BAdvD
MODO AVENTURA
Esta fun��o est� dispon�vel apenas no jogo RPG.
~
BPanic
P�NICO
Esta fun��o n�o est� dispon�vel.
~
BMessage
MENSAGEM (Tecla: ENTER)
Clique com o bot�o esquerdo para ler suas mensagens.
~
BNoMess
MENSAGEM
N�o h� novas mensagens.
~
BDisMess
MENSAGEM
Este recurso s� est� dispon�vel quando um restaurante � selecionado.
~
BOpen
Restaurante aberto
Clique com o bot�o esquerdo para abrir este restaurante ao p�blico!
~
BClose
Fechar restaurante
Clique com o bot�o esquerdo para fechar este restaurante.
~
BReo
Reabrir restaurante
Clique com o bot�o esquerdo para reabrir este restaurante.
~
BOpenD
Restaurante aberto
Esta fun��o s� est� dispon�vel quando um restaurante tiver sido selecionado ou dentro de um.
~
PopUpOk
OK
Confirme as altera��es ou sele��es feitas.
~
PopUpCan
Cancelar
Cancele altera��es ou sele��es feitas.
~
VCust
Ver detalhes do cliente
Clique com o bot�o esquerdo para visualizar os detalhes deste cliente.
~
Profile
Perfil do cliente
Clique com o bot�o esquerdo para visualizar o perfil deste cliente.
~
Order
Comida pedida
Clique com o bot�o esquerdo para ver o que este cliente pediu em seu restaurante.
~
Complain
Reclama��es de clientes
Clique com o bot�o esquerdo para ver uma lista de reclama��es que este cliente tem sobre o seu restaurante.
~
CloseCu
SA�DA
Feche o painel do cliente.
~
SwitList
Lista de clientes
Clique com o bot�o esquerdo para ver uma lista de clientes atualmente em seu restaurante.
~
SwitLisD
Lista de clientes
Esta fun��o n�o est� dispon�vel no modo de lista.
~
SatIcon
Satisfa��o do Cliente
Indica o grau de satisfa��o do cliente.
~
TimeIcon
Tempo de espera
Indica quanto tempo os clientes aguardaram a chegada de suas refei��es.
~
BillIcon
Valor da fatura
Indica a fatura total do cliente.
~
ComIcon
Reclama��es
Indica o n�mero de reclama��es que um cliente tem com o seu restaurante.
~
Profit
LUCRO DO �LTIMO M�S
Mostra o lucro total da sua empresa no �ltimo m�s. Clique com o bot�o esquerdo para visualizar o relat�rio da Demonstra��o de Resultados.
~
Revenue
SEU DINHEIRO
Mostra quanto dinheiro voc� tem.
~
Leave
SAIR DO RESTAURANTE
Clique com o bot�o esquerdo para sair do restaurante e voltar � vista exterior.
~
LeaveDis
SAIR DO RESTAURANTE
Este recurso est� desativado na vista externa.
~
CitySel
SELETOR DE CIDADE
Clique nas setas para alternar entre cidades.
~
NextCity
PR�XIMA CIDADE
Clique com o bot�o esquerdo para ir para a pr�xima cidade.
~
LastCity
CIDADE ANTERIOR
Clique com o bot�o esquerdo para ir para a cidade anterior.
~
StarRate
CLASSIFICA��O GERAL
Indica a classifica��o geral deste restaurante. Uma classifica��o de cinco estrelas � a mais alta. Clique com o bot�o esquerdo nas estrelas para ver as classifica��es deste restaurante.
~
StarRatN
CLASSIFICA��O GERAL
Indica a classifica��o geral deste restaurante. Uma classifica��o de cinco estrelas � a mais alta.
~
BeveCost
Custo de bebidas
Esta coluna mostra o custo de aquisi��o de bebidas.
~
BevePric
Pre�o da bebida
Esta coluna mostra o pre�o de venda padr�o da bebida.
~
BeveConf
Adicionar bebida
Adicione as bebidas selecionadas ao menu de comida do seu restaurante.
~
CloseBev
Sa�da
Feche o painel de bebidas.
~
OwnShow
Propriedade
Clique com o bot�o esquerdo para ver a propriedade do restaurante nesta cidade.
~
ProShow
Lucro
Clique com o bot�o esquerdo para ver os lucros dos restaurantes nesta cidade.
~
ValShow
Valor do terreno
Clique com o bot�o esquerdo para ver as taxas de valor dos terrenos nesta cidade.
~
AllShow
Mostrar todos os restaurantes
Clique com o bot�o esquerdo para ver todos os restaurantes que operam nesta cidade.
~
MyShow
Mostrar meus restaurantes
Clique com o bot�o esquerdo para ver todos os restaurantes que voc� possui e que operam nesta cidade.
~
ComShow
Mostrar restaurantes dos concorrentes
Clique com o bot�o esquerdo para ver todos os restaurantes de seus concorrentes que operam nesta cidade.
~
CloseMap
Sa�da
Feche o minimapa.
~
ChefAsOK
Confirmar
Confirme as altera��es ou sele��es feitas.
~
ChefAsCL
Cancelar
Cancela altera��es ou sele��es feitas.
~
ChefAsCN
Fechar
Feche a interface de atribui��o do chef.
~
ChefAsPR
Chef Anterior
Clique com o bot�o esquerdo para ver o chef anterior da lista.
~
ChefAsNE
Pr�ximo Chef
Clique com o bot�o esquerdo para ver o pr�ximo chef da lista.
~
ChefAsCR
Atribuir Chef
Clique com o bot�o esquerdo para designar este chef para preparar a receita selecionada.
~
ChefAsIR
Desmarque todos os ingredientes
Clique com o bot�o esquerdo para desmarcar todos os ingredientes para o preparo desta receita.
~
SUPPREST
Redefinir compras
Clique com o bot�o esquerdo para redefinir todas as compras especiais de fornecedores.
~
SUPPCLOS
Fechar
Feche o painel do fornecedor.
~
SUPPREMO
Remover
Remova o fornecedor selecionado da lista.
~
CloseRes
Fechar
Feche o painel do restaurante.
~
ResProOn
Alternar exibi��o de lucro
Clique com o bot�o esquerdo para alternar entre exibir e ocultar os lucros do seu restaurante. O bot�o est� ativado no momento.
~
ResProOf
Alternar exibi��o de lucro
Clique com o bot�o esquerdo para alternar entre exibir e ocultar os lucros do seu restaurante. O bot�o est� desativado no momento.
~
ResRevOn
Alternar exibi��o de receita
Clique com o bot�o esquerdo para alternar entre exibir e ocultar as receitas do seu restaurante. O bot�o est� ativado no momento.
~
ResRevOf
Alternar exibi��o de receita
Clique com o bot�o esquerdo para alternar entre exibir e ocultar as receitas do seu restaurante. O bot�o est� desativado no momento.
~
ResSwit
Lista de restaurantes
Clique com o bot�o esquerdo para ver uma lista de seus restaurantes.
~
ResMy
Meus restaurantes
Clique com o bot�o esquerdo para exibir apenas seus restaurantes.
~
ResOpp
Restaurantes concorrentes
Clique com o bot�o esquerdo para exibir apenas os restaurantes de seus concorrentes.
~
ResAll
Todos os restaurantes
Clique com o bot�o esquerdo para exibir todos os restaurantes.
~
ResRepo
Classifica��o do restaurante
Clique com o bot�o esquerdo para visualizar o relat�rio de classifica��o do seu restaurante.
~
CloseAdv
Fechar
Clique para fechar o painel de aventura.
~
BBuild
Menu Construir
Clique com o bot�o esquerdo para configurar um novo restaurante.
~
DBBuild
Menu Construir
Este menu fica desabilitado quando n�o h� pr�dios ou terrenos � venda.
~
BUPGRAD
Atualiza��o de restaurante
Clique com o bot�o esquerdo para abrir a interface de atualiza��o do restaurante.
~
DBUPGRA
Atualiza��o de restaurante
Esta fun��o s� est� dispon�vel quando um restaurante tiver sido selecionado ou dentro de um.
~
BSelLoc
Confirme a localiza��o selecionada
Selecione um local e clique aqui para construir um novo restaurante.
~
LAddress
Endere�o
Este � o endere�o do pr�dio existente � venda.
~
LCost
Custo
Isso indica o pre�o de venda.
~
BdClose
Fechar
Clique com o bot�o esquerdo para cancelar todas as altera��es e fechar a interface.
~
BdCancel
Cancelar
Clique com o bot�o esquerdo para cancelar todas as altera��es e fechar a interface.
~
BdAddres
Endere�o
Este � o endere�o do terreno � venda.
~
BdPrice
Pre�o
Isso indica o n�vel de pre�o do local. Quanto mais sinais �$�, mais caro ser� o valor do terreno, mas isso tamb�m significa que mais clientes abastados estar�o na �rea.
~
IpButton
Menu de restaurante independente
Clique aqui para estabelecer o novo restaurante como um restaurante independente.
~
FcButton
card�pio de restaurante franqueado
Clique aqui para estabelecer o novo restaurante como franquia.
~
FCuisine
cozinha francesa
Clique com o bot�o esquerdo para selecionar a culin�ria francesa como tema do restaurante.
~
ICuisine
Cozinha italiana
Clique com o bot�o esquerdo para selecionar culin�ria italiana como tema do restaurante.
~
ACuisine
Cozinha americana
Clique com o bot�o esquerdo para selecionar culin�ria americana como tema do restaurante.
~
GCuisine
Cozinha alem�
Clique com o bot�o esquerdo para selecionar a culin�ria alem� como tema do restaurante.
~
CCuisine
Cafeteria
Clique com o bot�o esquerdo para selecionar Cafeteria como tema do restaurante.
~
DCuisine
Casa de sobremesas
Clique com o bot�o esquerdo para selecionar Dessert house como tema do restaurante.
~
OneFloor
Um andar
Clique com o bot�o esquerdo para limitar seu novo restaurante a apenas um andar.
~
TwoFloor
Dois andares
Clique com o bot�o esquerdo para adicionar um segundo andar ao seu novo restaurante.
~
SSize
Tamanho do edif�cio 3X2
Clique com o bot�o esquerdo para definir o tamanho do novo restaurante para 3X2.
~
MSize
Tamanho do edif�cio 3X3
Clique com o bot�o esquerdo para definir o tamanho do novo restaurante para 3X3.
~
LSize
Tamanho do edif�cio 4X3
Clique com o bot�o esquerdo para definir o tamanho do novo restaurante para 4x3.
~
IpConfir
Confirmar
Confirme as altera��es ou sele��o feita.
~
IpCancel
Cancelar
Cancele todas as altera��es ou sele��es feitas.
~
IpClose
Fechar
Feche o painel do restaurante Independente.
~
FcConfir
Confirmar
Confirme altera��es ou sele��o.
~
FcCancel
Cancelar
Cancela altera��es ou sele��es feitas.
~
FcClose
Fechar
Clique aqui para fechar o painel do restaurante Franqueado.
~
LSuggest
Lista de sugest�es de nomes
Veja sugest�es de nomes para seu novo restaurante.
~
RrConfir
Construa agora!
Confirme as altera��es ou sele��es feitas.
~
RrCancel
Cancelar
Cancela altera��es ou sele��es feitas.
~
RrClose
Fechar
Clique aqui para fechar o painel Nome do restaurante.
~
RrLArrow
Nome sugerido anterior
Clique aqui para ver a sugest�o de nome anterior na lista.
~
RrRArrow
Pr�ximo nome sugerido
Clique aqui para ver a pr�xima sugest�o de nome na lista.
~
BiClose
Fechar
Clique aqui para fechar o painel de compra de ingredientes.
~
BiBuy
Confirmar
Clique aqui para comprar ingredientes.
~
BiCancel
Cancelar
Cancele todas as altera��es ou sele��es feitas.
~
BiInc
Aumentar
Clique aqui para aumentar a qualidade dos ingredientes desta receita.
~
BiDec
Diminuir
Clique aqui para diminuir a qualidade dos ingredientes desta receita.
~
BiZoom
Ampliar
Clique aqui para ver um close do ingrediente.
~
businD
Modo de neg�cios
Clique aqui para jogar no Modo Simula��o de Neg�cios.
~
RepoMana
Gerenciamento
Clique com o bot�o esquerdo para visualizar o painel de gerenciamento.
~
RepoList
Listas
Clique com o bot�o esquerdo para visualizar o painel de listas.
~
RepoRepo
Relat�rios
Clique com o bot�o esquerdo para visualizar o painel de relat�rios.
~
RepoGoal
Metas
Clique com o bot�o esquerdo para visualizar o painel de metas.
~
RePolicy
Pol�ticas do restaurante
Clique com o bot�o esquerdo para definir as pol�ticas do seu restaurante.
~
ReTrain
Treinamento de pessoal
Clique com o bot�o esquerdo para treinar sua equipe.
~
ReUnif
Uniforme
Clique com o bot�o esquerdo para alterar o uniforme de sua equipe.
~
ReAdvert
An�ncio
Clique com o bot�o esquerdo para anunciar seus restaurantes.
~
ReRcrsh
Pesquisa de receitas
Clique com o bot�o esquerdo para pesquisar uma nova receita.
~
ReLoan
Empr�stimo
Clique com o bot�o esquerdo para contrair ou pagar empr�stimos.
~
ReReLst
Lista de restaurantes
Clique com o bot�o esquerdo para ver uma lista de todos os restaurantes.
~
ReSupLst
Lista de fornecedores de ingredientes
Clique com o bot�o esquerdo para ver seus fornecedores de ingredientes especiais.
~
ReStar
Lista de chefs estrelas
Clique com o bot�o esquerdo para ver uma lista de chefs famosos.
~
RePpFd
Lista de alimentos populares
Clique com o bot�o esquerdo para ver a lista de classifica��o de alimentos populares.
~
RePfGLst
Lista de desempenho
Clique com o bot�o esquerdo para ver uma lista de desempenho.
~
ReFSpLst
Lista de fornecedores de m�veis
Clique com o bot�o esquerdo para ver uma lista de fornecedores de m�veis especiais.
~
ReCusLst
Personalizar exibi��o de lista
Clique com o bot�o esquerdo para escolher entre os diferentes indicadores de informa��o a serem exibidos.
~
ReResRt
Avalia��es de restaurantes (chave: F8)
Clique com o bot�o esquerdo para ver as avalia��es do seu restaurante.
~
ReSales
Relat�rio de vendas (chave: F9)
Clique com o bot�o esquerdo para visualizar seus relat�rios de vendas.
~
ReStat
Estat�sticas (chave: F10)
Clique com o bot�o esquerdo para visualizar estat�sticas do restaurante e outros dados.
~
ReIncome
Demonstra��es de resultados (chave: F11)
Clique com o bot�o esquerdo para visualizar suas demonstra��es de resultados.
~
ReGraph
Gr�ficos Financeiros (Chave: G)
Clique com o bot�o esquerdo para visualizar e tra�ar seu progresso por meio de gr�ficos financeiros.
~
ReComp
Reclama��es (chave: F12)
Clique com o bot�o esquerdo para ver uma lista de reclama��es registradas.
~
ReScore
Pontua��o
Clique com o bot�o esquerdo para ver a pontua��o do jogo.
~
ReGoal
Gol (chave: F1)
Clique com o bot�o esquerdo para ver seus objetivos de jogo.
~
RSRName
Nome do curso de alimenta��o
~
RSRQual
Qualidade Alimentar
~
RSRQuan
Quantidade vendida
~
RSRPrice
Pre�o
~
RSRPro
Lucro bruto
Veja seus lucros brutos.
~
RSRTPro
Lucro bruto total
Veja seus lucros brutos totais.
~
UgClose
Fechar
Clique aqui para fechar o painel de atualiza��o externa.
~
UgConfir
Confirmar
Confirme as altera��es ou sele��es feitas.
~
UgList
Lista de restaurantes
Clique com o bot�o esquerdo para ver uma lista de seus restaurantes.
~
UgBack
Voltar
Clique aqui para voltar ao painel externo de atualiza��o.
~
UgCancel
Cancelar
Cancela altera��es ou sele��es feitas.
~
UgFc
Candidate-se � franquia
Clique aqui para aplicar as atualiza��es selecionadas aos seus restaurantes franqueados.
~
MessClos
Fechar
Clique aqui para fechar o painel de mensagens.
~
MessList
Lista de mensagens
Clique com o bot�o esquerdo para ler os t�tulos das mensagens.
~
MessMess
Ler mensagens
Clique com o bot�o esquerdo para ler as mensagens.
~
MessGo
Ir
Leve-me l�!
~
MessCan
Fechar
Feche o painel de mensagens.
~
MessNext
Pr�xima mensagem
Clique com o bot�o esquerdo para ler sua pr�xima mensagem.
~
MessPrev
Mensagem anterior
Clique com o bot�o esquerdo para ler sua mensagem anterior.
~
IDClose
Fechar
Clique aqui para fechar o painel de detalhes do item.
~
IDConfir
Confirmar
Confirme as altera��es ou sele��es feitas.
~
IDDelete
Confirmar
Confirme suas altera��es ou sele��es feitas.
~
IDNAMENT
Pr�xima comodidade
Clique com o bot�o esquerdo para visualizar o pr�ximo item da lista.
~
IDPAMENT
Comodidade Anterior
Clique com o bot�o esquerdo para visualizar o item anterior da lista.
~
IDNAPPLY
Pr�xima op��o
Clique com o bot�o esquerdo para ver a pr�xima op��o da lista.
~
IDPAPPLY
Op��o Anterior
Clique com o bot�o esquerdo para ver a op��o anterior da lista.
~
IDLIGHT
Confirmar
Confirme as altera��es ou sele��es feitas.
~
SECRETIN
Ingrediente Secreto
Seu chef deve levar os ingredientes secretos necess�rios e voc� deve atribu�-los por meio da interface "Atribui��o do Chef e Ingredientes Estocados" no menu de comida se quiser preparar a vers�o "secreta" desta receita.
~
enableD
Ativar ingrediente
Habilite esses ingredientes na receita selecionada.
~
disableD
Desativar ingrediente
Desative esses ingredientes da receita selecionada.
~
trecipDN
Alternar filtragem
Alterne entre exibir todas as receitas e apenas aquelas que seu restaurante oferece atualmente.
~
trecipDS
Alternar filtro
Esta fun��o s� est� dispon�vel quando um restaurante tiver sido selecionado ou dentro de um.
~
tfoodDN
Alternar filtragem
Alternar a exibi��o das receitas do menu de comida do restaurante atual.
~
ss_D
Painel Especial de Fornecedores
Clique com o bot�o esquerdo para abrir o painel especial do fornecedor.
~
GAMEFNAM
Nome do arquivo do jogo
Indica o nome do arquivo do jogo salvo selecionado.
~
CCCHEFSR
Veja as habilidades de prepara��o do chef para esta receita.
~
CCINGREQ
Veja a receita e as classifica��es dos ingredientes.
~
CCFOODRA
Veja a classifica��o geral dos alimentos.
~
ccD
Prepare a receita selecionada.
~
ccView
Fecha a janela
~
ccOffer
Ofere�a a receita selecionada ao cliente.
~
discA_D
Desconto
Clique aqui para definir um desconto fixo em todas as receitas oferecidas em seu menu.
~
berbtDn
Adicionar bebida
Ofere�a uma variedade de bebidas para seus clientes acompanharem suas saborosas refei��es.
~
ChInPoFo
Siga a equipe
Clique duas vezes no retrato da pauta para que a c�mera siga esta pauta.
~
ChInPoFN
Pare de seguir a equipe
Clique duas vezes no retrato da pauta para impedir que a c�mera siga esta pauta.
~
CuFood
Receitas
Clique duas vezes no �cone da comida para ver as receitas dispon�veis.
~
ReProf
Barra de lucro
Esta barra indica os lucros do restaurante.
~
ReReve
Barra de receita
Esta barra indica as receitas do restaurante.
~
ChStSk
Habilidade Alimentar
Veja a profici�ncia do chef selecionado no preparo desta receita.
~
ChStRr
Avalia��o da receita
Veja a receita e as classifica��es dos ingredientes.
~
ChStOrr
Avalia��o geral
Veja a classifica��o geral dos alimentos.
~
ChStCt
Tempo de cozimento
Indica o tempo relativo de cozimento necess�rio para preparar esta receita.
~
CustFlw
Seguir o cliente
Clique duas vezes no retrato do cliente para que a c�mera siga esse cliente.
~
CustFlwN
Pare de seguir o cliente
Clique duas vezes no retrato do cliente para impedir que a c�mera siga esse cliente.
~
FlyPlace
V� para o local
Clique com o bot�o esquerdo para ir para o local destacado na lista.
~
RepoManD
Gerenciamento de relat�rios
A fun��o est� desabilitada para o cen�rio atual.
~
RepoLisD
Lista de relat�rios
A fun��o est� desabilitada para o cen�rio atual.
~
BTAdvD
MODO AVENTURA
A fun��o est� desabilitada para o cen�rio atual.
~
BTRecipe
MENU DE RECEITAS
A fun��o est� desabilitada para o cen�rio atual.
~
BTReport
CENTRO DE INFORMA��ES
A fun��o est� desabilitada para o cen�rio atual.
~
BTMenu
MENU DE COMIDA
A fun��o est� desabilitada para o cen�rio atual.
~
BTRest
LISTA DE RESTAURANTES
A fun��o est� desabilitada para o cen�rio atual.
~
BTChef
PAINEL DE PESSOAL
A fun��o est� desabilitada para o cen�rio atual.
~
BTCust
PAINEL DE CLIENTES
A fun��o est� desabilitada para o cen�rio atual.
~
BTBuild
Menu Construir
A fun��o est� desabilitada para o cen�rio atual.
~
BTOpen
Restaurante aberto
A fun��o est� desabilitada para o cen�rio atual.
~
BTUPGRAD
Atualiza��o de restaurante
A fun��o est� desabilitada para o cen�rio atual.
~
m_fur_d
Arranjos de assentos
A fun��o est� desabilitada para o cen�rio atual.
~
m_raw_d
Quartos e Texturas
A fun��o est� desabilitada para o cen�rio atual.
~
m_lg_d
Ilumina��o
A fun��o est� desabilitada para o cen�rio atual.
~
m_oth_d
Acess�rios
A fun��o est� desabilitada para o cen�rio atual.
~
BTClose
Fechar restaurante
A fun��o est� desabilitada para o cen�rio atual.
~
BTReo
Reabrir restaurante
Esta fun��o est� desabilitada para o cen�rio atual.
~
OfferFd
Ofere�a comida favorita
Clique com o bot�o esquerdo para oferecer aos clientes sua comida favorita.
~
OfferFds
Ofere�a comida favorita
Voc� n�o pode oferecer comida favorita a este cliente.
~
OfRecipe
Selecione a receita
Clique com o bot�o esquerdo para selecionar uma receita para oferecer ao cliente.
~
OfChef
Selecione Chef
Clique com o bot�o esquerdo para selecionar um chef para preparar a comida favorita deste cliente.
~
OfInPric
Aumentar o pre�o da oferta
Clique com o bot�o esquerdo para aumentar o pre�o de oferta desta receita.
~
OfDePric
Diminuir o pre�o da oferta
Clique com o bot�o esquerdo para diminuir o pre�o de oferta desta receita.
~
CustSat
Meta de 100% de satisfa��o do cliente
Indica o n�mero de vezes/o n�mero alvo de vezes que a meta de 100% de satisfa��o do cliente foi alcan�ada.
~
RECIPRIC
Pre�o padr�o
Este � o pre�o padr�o da receita selecionada.
~
EasyGoal
Meta mais f�cil
Reinicie o cen�rio atual com objetivo mais f�cil.
~
TryAgain
Meta normal
Reinicie o cen�rio atual com as mesmas configura��es.
~
Restart
Cen�rio de reinicializa��o
Reinicie o cen�rio atual
~
QuitMain
Saia para o menu principal.
Saia do cen�rio atual e retorne ao menu principal.
~
WallTogg
Alternar visibilidade da parede (tecla: W)
Clique com o bot�o esquerdo para ativar/desativar a visualiza��o das paredes. O modo est� atualmente desativado.
~
WallOff
Alternar visibilidade da parede (tecla: W)
Clique com o bot�o esquerdo para ativar/desativar a visualiza��o das paredes. O modo est� atualmente ativado.
~
NewEvent
Novo Evento
Clique com o bot�o esquerdo para ir para o pr�ximo evento.
~
NewEvenD
Novo Evento
N�o h� novos eventos.
~
minig_dn
Minijogos
Clique com o bot�o esquerdo para jogar um minijogo aleat�rio. Para cada minijogo que voc� passar com sucesso, seu chef ganhar� experi�ncia.
~
CCRecipe
Receitas
Clique com o bot�o esquerdo para selecionar uma receita para preparar para esta rodada do concurso de culin�ria.
~
CCIngred
Atribuir Chef
Clique com o bot�o esquerdo para selecionar um chef para preparar a receita selecionada para esta rodada.
~
BFupDi
ANDAR PARA CIMA
N�o � poss�vel mudar de andar
~
BFdoDi
ANDAR PARA BAIXO
N�o � poss�vel mudar de andar
~
UgExBu
Nome do restaurante, tipo de cozinha, classifica��o da empresa
~
InvName
Nome do invent�rio
~
InvQual
Qualidade
~
InvQuan
Quantidade
~
TvAd
Publicidade televisiva
A principal forma de publicidade. Alcance muito amplo, mas n�o muito direcionado. Efic�cia de at� 25%, mas muito cara. No entanto, a combina��o de �udio e v�deo na sua publicidade n�o pode ser subestimada.
~
RaAd
Publicidade em r�dio
A maneira impactante de alcan�ar as pessoas na estrada. Com at� 20% de efic�cia, � um pouco mais direcionado que a TV e mais barato de promover. Funciona perfeitamente como um lembrete sutil das campanhas de TV mais agressivas.
~
NeAd
Publicidade em jornais
Todo mundo l� os jornais! A publicidade moderadamente direcionada pode ser respons�vel por at� 15% de efic�cia. Os custos s�o muito acess�veis. Devido � natureza descart�vel dos jornais, no entanto, � necess�ria uma manuten��o constante para que sejam eficazes.
~
MaAd
Publicidade em revistas
O mais direcionado de todos os an�ncios. Pode ser respons�vel por at� 10% de efic�cia e � mais caro que os jornais. Por�m, as revistas s�o lidas diversas vezes, ent�o sua exposi��o � maior que a dos jornais.
~
MaxCSat
Meta de 100% de satisfa��o do cliente
Voc� atingiu a meta m�xima de satisfa��o do cliente.
~
SandPNam
Defina seu nome
Clique com o bot�o esquerdo na exibi��o do nome para alterar seu nome.
~
fr_d
Cozinha francesa
Clique com o bot�o esquerdo para definir a especializa��o do seu chef para culin�ria francesa.
~
it_d
Cozinha italiana
Clique com o bot�o esquerdo para definir a especializa��o do seu chef para culin�ria italiana.
~
am_d
Cozinha Americana
Clique com o bot�o esquerdo para definir a especializa��o do seu chef para culin�ria americana.
~
SandPChe
Chef Anterior
Clique com o bot�o esquerdo para ver o chef anterior.
~
SandNChe
Pr�ximo Chef
Clique com o bot�o esquerdo para ver o pr�ximo chef.
~
SandNext
V� para a pr�xima etapa
Clique com o bot�o esquerdo para confirmar suas escolhas e come�ar a configurar sua empresa.
~
SandMain
Menu Principal
Clique com o bot�o esquerdo para voltar ao menu principal.
~
SandCNam
Defina o nome da sua empresa
Clique com o bot�o esquerdo na exibi��o do nome da empresa para alterar o nome da sua empresa.
~
SandSCNa
Nomes de empresas sugeridos
Clique com o bot�o esquerdo na exibi��o do nome da empresa para ver sugest�es para o nome da sua empresa.
~
SandNCNa
Pr�ximo nome de empresa sugerido
Clique com o bot�o esquerdo para ver a pr�xima sugest�o de nome de empresa.
~
SandPCNa
Nome da empresa sugerido anteriormente
Clique com o bot�o esquerdo para visualizar a sugest�o de nome de empresa anterior.
~
blue_h
Azul
Clique com o bot�o esquerdo para definir a cor da sua empresa para azul. Todos os seus restaurantes aparecer�o em azul no minimapa.
~
brown_h
Marrom
Clique com o bot�o esquerdo para definir a cor da sua empresa como marrom. Todos os seus restaurantes aparecer�o em marrom no minimapa.
~
red_h
Vermelho
Clique com o bot�o esquerdo para definir a cor da sua empresa para vermelho. Todos os seus restaurantes aparecer�o em vermelho no minimapa.
~
green_h
Verde
Clique com o bot�o esquerdo aqui para definir a cor da sua empresa como verde. Todos os seus restaurantes aparecer�o em verde no minimapa.
~
yellow_h
Amarelo
Clique com o bot�o esquerdo para definir a cor da sua empresa como amarelo. Todos os seus restaurantes aparecer�o em amarelo no minimapa.
~
SandPlay
Jogue!
Clique com o bot�o esquerdo na caixa de sele��o para confirmar todas as escolhas e iniciar seu novo jogo.
~
RecipNam
Barra de exibi��o do nome da receita
Clique com o bot�o esquerdo para ver uma lista de receitas dispon�veis.
~
RecipZoo
Fechar-se
Clique com o bot�o esquerdo para ver um close da receita selecionada.
~
InIngrQu
Aumente a qualidade dos ingredientes
Clique com o bot�o esquerdo para aumentar a qualidade do ingrediente selecionado.
~
DeIngrQu
Diminuir a qualidade dos ingredientes
Clique com o bot�o esquerdo para diminuir a qualidade do ingrediente selecionado.
~
IngrEnab
Adicionar ingrediente
Clique com o bot�o esquerdo para adicionar o ingrediente selecionado � receita.
~
IngrDisa
Remover ingrediente
Clique com o bot�o esquerdo para remover o ingrediente selecionado da receita.
~
CloseInt
Fechar interface
Feche a interface atual.
~
MessHead
T�tulos de mensagens
Clique com o bot�o esquerdo em um t�tulo para ler a mensagem detalhada.
~
MinExtRe
Renderiza��o externa durante a visualiza��o do interior
Ative a renderiza��o externa se desejar que a parte externa do restaurante seja renderizada dentro dos restaurantes; isso pode fazer com que seu computador fique lento. Desative a renderiza��o externa se as taxas de quadros ficarem muito lentas e inst�veis.
~
chefDn
Mudar Chef
Clique com o bot�o esquerdo para selecionar outro chef para interagir com o cliente.
~
ChefAsCE
Atribuir Chef
Clique com o bot�o esquerdo para redefinir todas as atribui��es do chef. N�o haver� chefs dedicados a preparar esta receita.
~
ChefAIUp
Caixa de sele��o Adicionar ingrediente
Clique com o bot�o esquerdo para adicionar este ingrediente � receita selecionada.
~
ChefAIDn
Caixa de sele��o Adicionar ingrediente
Clique com o bot�o esquerdo para excluir este ingrediente da receita selecionada.
~
ReMaRena
Nome do restaurante
Clique com o bot�o esquerdo para alterar o nome do restaurante selecionado.
~
OpenHouP
Definir hor�rio de funcionamento posterior
Clique com o bot�o esquerdo para definir um hor�rio de funcionamento posterior.
~
OpenHouM
Definir hor�rio de funcionamento mais cedo
Clique com o bot�o esquerdo para definir um hor�rio de funcionamento anterior.
~
ClosHouP
Definir hor�rio de fechamento posterior
Clique com o bot�o esquerdo para definir um hor�rio de fechamento posterior.
~
ClosHouM
Definir hor�rio de fechamento mais cedo
Clique com o bot�o esquerdo para definir um hor�rio de fechamento mais cedo.
~
LastHouP
Definir hor�rios do �ltimo pedido posteriormente
Clique com o bot�o esquerdo para definir um hor�rio posterior para os �ltimos pedidos.
~
LastHouM
Definir hor�rios anteriores do �ltimo pedido
Clique com o bot�o esquerdo para definir um hor�rio anterior para os �ltimos pedidos.
~
CustShar
Compartilhamento de mesa
Compartilhar mesas pode acomodar mais clientes, mas �s custas da privacidade e, mais ainda, da satisfa��o do cliente. Clicar com o bot�o esquerdo em sim permite o compartilhamento de tabelas; Clicar com o bot�o esquerdo em n�o desativar� o compartilhamento de mesa.
~
SpenBarT
Barra de treinamento mensal da equipe
Clique ou arraste a barra de porcentagem de gastos mensais para definir os custos mensais de treinamento da equipe do restaurante selecionado.
~
SpenBarA
Barra de gastos mensais com publicidade
Clique ou arraste na barra de porcentagem de gastos mensais para definir os custos mensais de publicidade do restaurante selecionado.
~
ReciGrdR
Grau da receita
A nota atual da sua pesquisa de receitas. Uma nota mais alta significa uma receita de melhor qualidade.
~
SpenBarR
Barra de gastos mensais de pesquisa
Clique ou arraste na barra de porcentagem de gastos mensais para definir o or�amento a ser gasto na pesquisa de novas receitas para uma categoria alimentar espec�fica. Aumentar seu or�amento aumentar� a taxa de pesquisa em sua respectiva categoria. Observe, entretanto, que assumir muitos projetos de pesquisa ao mesmo tempo diminuir� a efici�ncia de sua pesquisa e ter� um efeito negativo em sua taxa geral de pesquisa.
~
ProgBarR
Barra de progresso mensal de pesquisa
O progresso atual da sua pesquisa de receitas. A nova receita � pesquisada quando a barra estiver cheia.
~
BorrowP
Aumentar o valor do empr�stimo
Clique com o bot�o esquerdo para aumentar o valor do empr�stimo.
~
BorowM
Menor valor do empr�stimo
Clique com o bot�o esquerdo para diminuir o valor do empr�stimo.
~
RepayP
Reembolsar mais
Clique com o bot�o esquerdo para pagar mais do seu empr�stimo.
~
RepayM
Pague menos
Clique com o bot�o esquerdo para pagar menos do seu empr�stimo.
~
NComp
Alternar entre empresas
Clique com o bot�o esquerdo para alternar entre sua empresa e todas as empresas.
~
LComp
Alternar entre empresas
Clique com o bot�o esquerdo para alternar entre sua empresa e todas as empresas.
~
NCity
Pr�xima cidade
Clique com o bot�o esquerdo para ir para a pr�xima cidade.
~
LCity
Cidade Anterior
Clique com o bot�o esquerdo para ir para a cidade anterior.
~
LstPeri
Alternar per�odo
Clique com o bot�o esquerdo para alternar entre a exibi��o de informa��es ocorridas hoje, no m�s passado, no ano passado e ao longo da vida.
~
NxtPeri
Alternar per�odo
Clique com o bot�o esquerdo para alternar entre a exibi��o de informa��es ocorridas hoje, no m�s passado, no ano passado e ao longo da vida.
~
RaiseBut
AUMENTAR/BAIXAR SAL�RIO
Aumentar ou diminuir o sal�rio do funcion�rio selecionado.
~
RaisDisH
AUMENTAR/BAIXAR SAL�RIO
Esta fun��o n�o est� dispon�vel na contrata��o de pessoal.
~
RaisDisL
AUMENTAR/BAIXAR SAL�RIO
Esta fun��o n�o est� dispon�vel ao visualizar a lista de funcion�rios.
~
RaisDisN
AUMENTAR/BAIXAR SAL�RIO
Esta fun��o n�o est� dispon�vel se voc� n�o tiver funcion�rios para ajustar seus sal�rios.
~
TranDisH
PESSOAL DE TRANSFER�NCIA
[Esta fun��o n�o est� dispon�vel na contrata��o de pessoal.
~
TranDisL
PESSOAL DE TRANSFER�NCIA
Esta fun��o n�o est� dispon�vel ao visualizar a lista de funcion�rios.
~
TranDisN
PESSOAL DE TRANSFER�NCIA
Esta fun��o n�o est� dispon�vel se voc� n�o tiver empregados para transferir.
~
FireDisH
EQUIPE DE BOMBEIROS
Esta fun��o n�o est� dispon�vel na contrata��o de pessoal.
~
FireDisL
EQUIPE DE BOMBEIROS
Esta fun��o n�o est� dispon�vel ao visualizar a lista de funcion�rios.
~
FireDisN
EQUIPE DE BOMBEIROS
Esta fun��o n�o est� dispon�vel se voc� n�o tiver funcion�rios para demitir.
~
OAppDisH
OFERECE APRENDIZAGEM
Esta fun��o n�o est� dispon�vel na contrata��o de pessoal.
~
OAppDisL
OFERECE APRENDIZAGEM
Esta fun��o n�o est� dispon�vel ao visualizar a lista de funcion�rios.
~
OAppDisN
OFERECE APRENDIZAGEM
Esta fun��o n�o est� dispon�vel se voc� n�o tiver funcion�rios para oferecer est�gio.
~
OAppDisC
OFERECE APRENDIZAGEM
Esta fun��o est� dispon�vel apenas para um chef.
~
OAppDisU
OFERECE APRENDIZAGEM
Esta fun��o n�o est� dispon�vel para esta pessoa.
~
OAppDisF
OFERECE APRENDIZAGEM
Este chef j� � seu aprendiz.
~
TAppDisH
TERMINAR APRENDIZAGEM
Esta fun��o n�o est� dispon�vel na contrata��o de pessoal.
~
TAppDisL
TERMINAR APRENDIZAGEM
Esta fun��o n�o est� dispon�vel ao visualizar a lista de funcion�rios.
~
TAppDisN
TERMINAR APRENDIZAGEM
Esta fun��o n�o est� dispon�vel se voc� n�o tiver funcion�rios para encerrar o aprendizado.
~
TAppDisC
TERMINAR APRENDIZAGEM
Esta fun��o est� dispon�vel apenas para um chef.
~
TAppDisF
TERMINAR APRENDIZAGEM
Este chef n�o � seu aprendiz.
~
TAppDisU
TERMINAR APRENDIZAGEM
Esta fun��o n�o est� dispon�vel para esta pessoa.
~
NextCust
Pr�ximo cliente
Clique com o bot�o esquerdo para visualizar o pr�ximo cliente na lista.
~
LastCust
Cliente anterior
Clique com o bot�o esquerdo para visualizar o cliente anterior na lista.
~
ReadMess
T�tulos de mensagens
Clique com o bot�o esquerdo em um t�tulo para ler a mensagem detalhada.
~
IngrName
Nome do ingrediente
Indica o ingrediente � venda.
~
IngrStar
Qualidade dos Ingredientes
Indica a qualidade do ingrediente.
~
IngrPric
Pre�o do ingrediente
Indica o pre�o do ingrediente por unidade de medida.
~
IngrAmou
Quantidade de ingrediente
Indica a quantidade do ingrediente para compra.
~
IngrTota
Pre�o total
Este � o pre�o total de compra do ingrediente.
~
AdvLocBa
Exibi��o de localiza��o
Clique com o bot�o esquerdo para destacar um local. Clique duas vezes para ir para o local selecionado.
~
SandINPr
Aumentar o capital inicial
Clique com o bot�o esquerdo para aumentar seu capital inicial.
~
SandDEPr
Diminuir o capital inicial
Clique com o bot�o esquerdo para diminuir seu capital inicial.
~
SandBack
Voltar
Clique com o bot�o esquerdo para voltar ao menu de configura��o do personagem do jogador.
~
SandMusi
Tema musical
Clique com o bot�o esquerdo para definir seu primeiro restaurante com um tema musical.
~
SandStea
Tema Churrascaria
Clique com o bot�o esquerdo para definir o tema de churrascaria em seu primeiro restaurante.
~
SandSeaf
Tema de frutos do mar
Clique com o bot�o esquerdo para definir seu primeiro restaurante com tema de frutos do mar.
~
SuppBar
Barra de Fornecedor Especial
Clique com o bot�o esquerdo em uma barra de fornecedor especial para selecionar o ingrediente a ser comprado. Para comprar, clique com o bot�o esquerdo no bot�o confirmar.
~
SuppSupp
Fornecedor
Indica o nome do fornecedor especial.
~
SuppInve
Invent�rio
Indica o estoque de ingredientes que o fornecedor especial possui.
~
SuppPric
Pre�o
Indica o pre�o do ingrediente por unidade.
~
SuppQual
Qualidade
Indica a qualidade do ingrediente.
~
SuppPurc
Comprar
Indica o valor de compra do ingrediente selecionado, se houver.
~
FdMeDcUp
Aumentar o valor do desconto
Clique com o bot�o esquerdo para aumentar a taxa de desconto para todas as receitas do menu.
~
FdMeDcDn
Diminuir valor do desconto
Clique com o bot�o esquerdo para diminuir a taxa de desconto para todas as receitas do menu.
~
FdMuBkRi
Pr�ximo plano de fundo
Clique com o bot�o esquerdo para alterar o design de plano de fundo do seu menu para o pr�ximo da lista.
~
FdMuBkLe
Antecedentes Anteriores
Clique com o bot�o esquerdo para alterar o design de plano de fundo do seu menu para um anterior na lista.
~
FdMuTeRi
Pr�xima fonte de texto
Clique com o bot�o esquerdo para alterar a fonte do texto do seu menu para a pr�xima na lista de fontes.
~
FdMuTeLe
Fonte do texto anterior
Clique com o bot�o esquerdo para alterar a fonte do texto do seu menu para uma anterior na lista de fontes.
~
FdMuTiRi
Fonte do pr�ximo t�tulo
Clique com o bot�o esquerdo para alterar a fonte do t�tulo do menu para a pr�xima na lista de fontes.
~
FdMuTiLe
Fonte do t�tulo anterior
Clique com o bot�o esquerdo para alterar a fonte do t�tulo do seu menu para uma anterior na lista de fontes.
~
FdMuRPrI
Aumentar o pre�o da receita
Clique com o bot�o esquerdo para aumentar o pre�o de venda da receita selecionada.
~
FdMuRPrD
Diminuir o pre�o da receita
Clique com o bot�o esquerdo para diminuir o pre�o de venda da receita selecionada.
~
FdMuBPrI
Aumentar o pre�o da bebida
Clique com o bot�o esquerdo para aumentar o pre�o de venda da bebida selecionada.
~
FdMuBPrD
Diminuir o pre�o da bebida
Clique com o bot�o esquerdo para diminuir o pre�o de venda da bebida selecionada.
~
FdMuSPrI
Aumentar o pre�o definido
Clique com o bot�o esquerdo para aumentar o pre�o de venda da refei��o selecionada.
~
FdMuSPrD
Diminuir pre�o definido
Clique com o bot�o esquerdo para diminuir o pre�o de venda da refei��o selecionada.
~
FdMuAsCh
Atribuir Chef
Clique com o bot�o esquerdo para designar um chef para preparar a receita selecionada.
~
OfConDis
Confirmar
Voc� deve primeiro designar um chef para preparar a receita a ser oferecida ao cliente por um determinado pre�o antes de confirmar as altera��es.
~
SaveNew
Salvar novo jogo
Clique com o bot�o esquerdo para selecionar salvar nova barra. Clique duas vezes para salvar o jogo atual em um novo slot.
~
HELPNEXT
Pr�ximo
Clique com o bot�o esquerdo para a pr�xima etapa do tutorial.
~
HELPMIN
Minimizar
Clique com o bot�o esquerdo para minimizar o painel do tutorial.
~
HELPMAX
Maximizar
Clique com o bot�o esquerdo para maximizar o painel do tutorial.
~
HELPCOMP
Completo
Clique com o bot�o esquerdo para finalizar o tutorial.
~
CCS1Forg
Esque�a
Clique com o bot�o esquerdo se n�o quiser entrar no concurso de culin�ria.
~
CCS1Join
Cadastre-se agora!
Clique com o bot�o esquerdo para participar deste concurso de culin�ria.
~
CCS2ViCh
Ver detalhes do chef
Clique com o bot�o esquerdo para ver informa��es detalhadas sobre o chef selecionado.
~
CCS2JOIN
Selecione este chef
Clique com o bot�o esquerdo para selecionar este chef para entrar no concurso de culin�ria.
~
CCS2DRO1
Soltar Chef
Clique com o bot�o esquerdo para descartar este chef.
~
CCS2ENT1
Entrar no concurso
Clique com o bot�o esquerdo para selecionar este chef para entrar no concurso de culin�ria.
~
CCS2DRO2
Soltar Chef
Clique com o bot�o esquerdo para retirar este chef da equipe.
~
CCS2ENT2
Entrar no concurso
Clique com o bot�o esquerdo para confirmar a sele��o da sua equipe de chefs e entrar no concurso de culin�ria.
~
CCQuit
Desistir
Clique com o bot�o esquerdo para desistir de todo o concurso de culin�ria e voltar para a vista externa.
~
CCReput
Reputa��o
Indica a classifica��o de reputa��o do chef selecionado.
~
AwRecipe
Receita premiada
Este �cone indica se esta receita ganhou algum pr�mio ou concurso de culin�ria de prest�gio.
~
NewRecip
Nova receita
Esta � uma nova receita. Voc� n�o oferece este prato em seu restaurante.
~
AARecipe
Atualmente oferecido
Esta receita est� sendo oferecida neste restaurante.
~
BdLocBar
Barra de exibi��o de localiza��o
Clique com o bot�o esquerdo na barra de exibi��o para visualizar detalhes do edif�cio ou terreno selecionado. Clique duas vezes na barra de exibi��o para confirmar sua sele��o e come�ar a configurar seu novo restaurante.
~
BdLgtInt
Controle deslizante de intensidade de luz
Clique com o bot�o esquerdo e arraste o controle deslizante para ajustar a intensidade da luz.
~
BdLgtRad
Controle deslizante de raio de luz
Clique com o bot�o esquerdo e arraste o controle deslizante para ajustar o raio de ilumina��o.
~
BdAppBar
Barra de aplica��o de itens
Clique com o bot�o esquerdo na barra de exibi��o para ver uma lista de op��es dispon�veis.
~
RpSpSp
Fornecedor
Indica o nome do fornecedor especial.
~
RpSpCy
Cidade
Indica a cidade onde est� localizado o fornecedor especial.
~
RpSpIn
Invent�rio
Indica o estoque de ingredientes que o fornecedor especial possui.
~
RpSpPr
Pre�o
Indica o pre�o do ingrediente por unidade.
~
RpSpQu
Qualidade
Indica a qualidade do ingrediente.
~
RpPgPt
Tipo de desempenho
Indica o tipo de desempenho.
~
RpPgPn
Nome do desempenho
Indica o nome do desempenho.
~
RpPgHr
Taxa hor�ria
Indica o pre�o de desempenho por hora.
~
RpPgQt
Avalia��o
Indica a classifica��o de desempenho.
~
RpPgAv
Disponibilidade
Indica a disponibilidade de desempenho.
~
RpFsDr
Designer
Isso mostra o nome da empresa de design.
~
RpFsFt
Tipo de mobili�rio
Mostra o tipo de mobili�rio em que o fornecedor � especializado.
~
SeatOccu
OCUPA��O DE ASSENTOS
Mostra a ocupa��o de assentos deste restaurante.
~
BIRecipe
Ver menu de receitas
Clique com o bot�o esquerdo para ver suas receitas e os ingredientes necess�rios.
~
icInMenu
Atualmente oferecido
Esta receita est� sendo oferecida neste restaurante.
~
icNew
Nova receita
Esta � uma nova receita. Voc� n�o oferece este prato em seu restaurante.
~
icWinCC
Receita premiada
Este �cone indica se esta receita ganhou algum pr�mio ou concurso de culin�ria de prest�gio.
~
FdReSale
Indicador de vendas
Indica o volume de vendas do prato de comida destacado no �ltimo m�s.
~
FdFoodRa
Indicador de Qualidade
Indica a qualidade do prato destacado.
~
FdWinCC
Prato Premiado
Este � um prato premiado.
~
Eiffel
Marco
A Torre Eiffel
~
Louvre
Marco
museu do Louvre
~
Trium
Marco
Arco do Triunfo
~
Basil
Marco
Bas�lica de S�o Pedro no Vaticano
~
ColoSseu
Marco
Coliseu
~
HollWood
Marco
O sinal nas colinas de Hollywood
~
Frauenk
Marco
Dom zu unserer lieben Frau
~
Hofbrau
Marco
Staatliches Hofbr�uhaus
~
Townhall
Marco
Deutsch Neues Rathaus Glockenspiel
~
ccScRigh
Pr�xima receita
Clique com o bot�o esquerdo para ver a pr�xima receita que est� em conformidade com as regras do concurso de culin�ria.
~
ccScLeft
Receita Anterior
Clique com o bot�o esquerdo para ver a receita anterior que est� em conformidade com as regras do concurso de culin�ria.
~
aroom_ds
Ajustar salas
A fun��o est� desabilitada para o cen�rio atual.
~
droom_ds
Excluir salas
A fun��o est� desabilitada para o cen�rio atual.
~
s_roo_ds
Adicionar salas
A fun��o est� desabilitada para o cen�rio atual.
~
ResSwitD
Lista de restaurantes
A fun��o est� desabilitada para o cen�rio atual.
~
CHlName
Nome da Unidade
Mostra o nome das unidades.
~
CHlSkill
Habilidades
Mostra as habilidades das unidades.
~
CHlWage
Sal�rio esperado
Mostra o sal�rio esperado das unidades.
~
MGHELP
Instru��es
Clique com o bot�o esquerdo para ler as instru��es para jogar este minijogo.
~
MGQUIT
Sair do minijogo
Clique com o bot�o esquerdo para sair do minijogo atual.
~
NewEveTD
Novo Evento
A fun��o est� desabilitada para o cen�rio atual.
~
TBNoMess
MENSAGEM
A fun��o est� desabilitada para o cen�rio atual.
~
TrashInv
Remover ingrediente
Clique com o bot�o esquerdo para remover este ingrediente do invent�rio do chef.
~
TimeBar
Barra de exibi��o do per�odo
Clique com o bot�o esquerdo na exibi��o do per�odo de tempo para alterar o per�odo de exibi��o.
~
Proceed
Prosseguir para o pr�ximo m�s
Clique com o bot�o esquerdo para prosseguir para o pr�ximo m�s.
~
Tips
Pontas
Clique com o bot�o esquerdo para ver algumas dicas �teis para jogar Restaurant Empire.
~
TipsDi
Pontas
As dicas de ajuda n�o est�o dispon�veis no momento.
~
NTip
Pr�xima dica
Clique com o bot�o esquerdo para ver a pr�xima dica.
~
PTip
Dica anterior
Clique com o bot�o esquerdo para ver a dica anterior.
~
NTCat
Pr�xima categoria de dica
Clique com o bot�o esquerdo para ir para a pr�xima categoria de dicas.
~
PTCat
Categoria de dica anterior
Clique com o bot�o esquerdo para ir para a categoria de dica anterior.
~
TipBar
Barra de exibi��o de categorias de dicas
Clique com o bot�o esquerdo em qualquer lugar na exibi��o de categorias de dicas para visualizar uma lista suspensa de categorias de dicas.
~
AllSkill
Todas as habilidades
Indica as habilidades de receita de todas as receitas que este chef conhece. Clique com o bot�o esquerdo para ver as habilidades deste chef apenas para as receitas oferecidas no menu do restaurante.
~
MenuSkil
Habilidades do card�pio
Indica as habilidades das receitas que este chef conhece e aparecem no card�pio do restaurante. Clique com o bot�o esquerdo para ver as habilidades deste chef para todas as receitas.
~
AssnAuto
Atribui��o autom�tica
Clique com o bot�o esquerdo no bot�o de op��o para atribuir automaticamente o funcion�rio selecionado a andares diferentes.
~
AssnFirs
Atribuir ao primeiro andar
Clique com o bot�o esquerdo no bot�o de op��o para atribuir o funcion�rio selecionado ao primeiro andar.
~
AssnSeco
Atribuir ao segundo andar
Clique com o bot�o esquerdo no bot�o de op��o para atribuir o funcion�rio selecionado ao segundo andar.
~
TAssAuto
Atribui��o autom�tica de tarefas
Clique com o bot�o esquerdo no bot�o de op��o para permitir que o jogo atribua tarefas automaticamente ao porteiro da cozinha.
~
TAssWash
Lavar pratos
Clique com o bot�o esquerdo no bot�o de op��o para designar o porteiro da cozinha para lavar a lou�a.
~
TAssDumb
Operar Gar�om Mudo
Clique com o bot�o esquerdo no bot�o de op��o para designar o porteiro da cozinha para operar o monta-cargas.
~
MysBut
ITEM MISTERIOSO
Clique com o bot�o esquerdo para usar os itens que voc� possui
~
MysDisF
ITEM MISTERIOSO
Voc� n�o possui nenhum item misterioso.
~
MysDisH
ITEM MISTERIOSO
Esta fun��o n�o est� dispon�vel na contrata��o de pessoal.
~
MysDisN
ITEM MISTERIOSO
Esta fun��o n�o estar� dispon�vel se voc� n�o tiver nenhum alvo.
~
MysDisL
ITEM MISTERIOSO
Esta fun��o n�o est� dispon�vel ao visualizar a lista de funcion�rios.
~
OpSrnRes
Resolu��o da tela
Esta fun��o est� dispon�vel apenas no menu principal.
~